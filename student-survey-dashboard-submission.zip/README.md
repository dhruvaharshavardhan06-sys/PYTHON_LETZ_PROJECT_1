# 📊 Student Survey Dashboard (Python 3-Tier Edition)

> **LocalImpact Challenge · Project #100 · Data & Visualization**  
> **Student / Team:** `mrv_icb_gp3` · **Roll No:** `MRVICB2630003`  
> **Tech Stack:** Python 3.10+ · Pandas · Matplotlib · Pytest · JSON/CSV Persistence

A production-structured, **3-tier Python application** for collecting, validating, filtering, analyzing, visualizing, and exporting student survey data via an interactive **CLI menu** (SRS §4.1) and automated command-line flags.

---

## 🏗️ 3-Tier Architecture

```
student-survey-dashboard/
├── main.py                               # CLI entry point
├── requirements.txt                      # pandas, matplotlib, pytest
├── pyproject.toml                        # Packaging & pytest configuration
├── docs/
│   └── SRS.md                            # Software Requirements Specification (3-tier & §4.1 CLI)
├── survey_dashboard/
│   ├── config.py                         # AppConfig, domain constants, thresholds
│   ├── models.py                         # SurveyRecord, FilterCriteria, ThresholdAlert, ImportSummary
│   ├── data/                             # TIER 1 — Data Access / Persistence Layer
│   │   ├── repository.py                 # SurveyRepository ABC + FileSurveyRepository (atomic JSON + CSV)
│   │   └── seeder.py                     # Reproducible 35-student sample dataset generator
│   ├── business/                         # TIER 2 — Business Logic Layer
│   │   ├── security.py                   # Path traversal guard, CSV injection defense, PIN auth, audit log
│   │   ├── validators.py                 # 8-field strict validation & duplicate ID detection
│   │   ├── analytics.py                  # Pandas filtering, groupby, correlations & risk warnings
│   │   ├── visualizer.py                 # Matplotlib PNG chart suite (6 charts + executive dashboard)
│   │   ├── exporter.py                   # CSV, JSON, Markdown, and Plain Text exporter
│   │   └── service.py                    # SurveyService facade coordinating Tier 1 & Tier 2
│   └── presentation/                     # TIER 3 — Presentation Layer
│       └── cli.py                        # Interactive SRS §4.1 numbered CLI menu + argparse runner
└── tests/                                # Automated pytest suite
    ├── test_validators_and_security.py
    ├── test_repository.py
    ├── test_analytics_and_export.py
    ├── test_visualizer.py
    └── test_cli.py
```

---

## 🚀 Quick Start

### 1. Create Virtual Environment & Install Dependencies
```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux / macOS:
# source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Run in Browser (Python 3-Tier Web Server)
```bash
python main.py --web --open
# Opens at http://127.0.0.1:8787 (override with --port 8080)
```

### Running from VS Code
1. Open the folder `C:\Users\koushik\.gemini\antigravity\scratch\student-survey-dashboard` in VS Code (**File → Open Folder...**).
2. VS Code automatically uses `.venv\Scripts\python.exe` via `.vscode/settings.json`.
3. Press **`F5`** (or open **Run and Debug**) and choose:
   - **Run Web Dashboard (Browser)** — starts the Python server and opens `http://127.0.0.1:8787` automatically
   - **Run Interactive CLI Menu (SRS 4.1)** — launches the numbered CLI menu in the integrated terminal
   - **Generate Summary, Charts & Exports** — runs `--summary --charts --export all`
   - **Run Pytest Suite** — runs `pytest -v` (also integrated in VS Code's Testing sidebar)
4. Or run **`Terminal → Run Task...`** (`Start Browser Dashboard`, `Run Interactive CLI`, `Run Pytest Suite`).

### 3. Run Interactive CLI Menu (SRS §4.1)
```bash
python main.py
```

### 4. Run Non-Interactive CLI Commands
```bash
# Print executive KPI summary and warnings
python main.py --summary

# Generate all Matplotlib PNG charts into outputs/charts/
python main.py --charts

# Export CSV, JSON, Markdown, and Plain Text reports into outputs/exports/
python main.py --export all

# Optional: Protect Delete/Reset actions with an Admin PIN
python main.py --admin-pin 1234
```

### 5. Run Automated Tests
```bash
pytest -v
```

---

## ✨ Features & Rubric Alignment

### 1. Interactive CLI Menu (SRS §4.1)
1. **View Dashboard Summary & Warnings** — KPIs, median/std dev, top department, threshold alerts
2. **Add New Survey Entry** — Real-time field validation, canonical department/year picker, duplicate ID check
3. **Browse All Records** — Paginated tabular view (10 records/page)
4. **Search & Filter Records (Pandas)** — Multi-criteria filtering by keyword, department, year, and score range
5. **Edit Existing Record** — Update fields with full validation
6. **Delete Record** — Confirmation prompt + optional Admin PIN check
7. **View Analytics, Correlations & At-Risk Students** — Pearson `r` correlations, department/year Pandas `groupby`, multi-flag risk ranking
8. **Generate Matplotlib Visualizations** — Saves 7 high-DPI PNG charts to `outputs/charts/`
9. **Export Data & Reports** — Downloads/writes `CSV`, `JSON`, `Markdown`, and `Plain Text` reports to `outputs/exports/`
10. **Bulk Import CSV** — Row-by-row validation and duplicate rejection
11. **Reset to Sample Dataset** — Restores the 35-student sample cohort

### 2. Matplotlib Charts Generated (`outputs/charts/`)
- `score_distribution.png` — 5-band histogram with cohort mean
- `department_responses.png` — Donut chart of responses per department
- `satisfaction_vs_score.png` — Scatter plot with linear trendline & Pearson `r`
- `study_hours_and_attendance.png` — Dual histogram subplots
- `avg_score_by_department.png` — Horizontal bar chart with threshold marker
- `year_satisfaction_and_trend.png` — Dual-axis score & satisfaction progression
- `executive_dashboard.png` — 2×2 composite executive dashboard

### 3. Security & Robustness
- **Path Traversal Defense:** `safe_resolve_path()` restricts CSV import and file export paths to approved directories.
- **CSV Formula Injection Defense:** `sanitize_csv_cell()` neutralizes leading `=`, `+`, `-`, `@`, `\t`, `\r` characters on CSV export.
- **Atomic Persistence:** `FileSurveyRepository` writes via temporary file + `os.fsync` + `os.replace` to prevent file corruption, with JSON→CSV fallback recovery.
- **Input Sanitization & Strict Typing:** Rejects booleans/floats for integer fields, strips control characters, enforces regex on `studentId`.
- **Optional Admin PIN & Audit Log:** Constant-time `hmac.compare_digest` PIN verification for destructive actions and append-only `data/audit.log`.
