"""Top-level entry point for the Student Survey Dashboard CLI application."""

from __future__ import annotations

import sys

from survey_dashboard.presentation.cli import main

if __name__ == "__main__":
    sys.exit(main())
