"""Tests for validation rules, duplicate ID checks, security sanitization, path guards, and PIN auth."""

from __future__ import annotations

from pathlib import Path

import pytest

from survey_dashboard.business.security import (
    SecurityError,
    hash_pin,
    safe_resolve_path,
    sanitize_csv_cell,
    sanitize_text,
    verify_pin,
)
from survey_dashboard.business.validators import ValidationError, validate_and_build_record, validate_field


def test_validate_field_boundaries() -> None:
    assert validate_field("name", "Al") == ""
    assert validate_field("name", "A") != ""
    assert validate_field("student_id", "STU-001") == ""
    assert validate_field("student_id", "ab") != ""
    assert validate_field("student_id", "INVALID@ID") != ""
    assert validate_field("department", "Computer Science") == ""
    assert validate_field("department", "Astrology") != ""
    assert validate_field("year", "3rd Year") == ""
    assert validate_field("year", "10th Year") != ""
    assert validate_field("score", 0) == ""
    assert validate_field("score", 100) == ""
    assert validate_field("score", 101) != ""
    assert validate_field("score", True) != ""
    assert validate_field("score", 88.5) != ""
    assert validate_field("satisfaction", 1) == ""
    assert validate_field("satisfaction", 0) != ""
    assert validate_field("study_hours", 168) == ""
    assert validate_field("study_hours", 169) != ""
    assert validate_field("attendance", 100) == ""
    assert validate_field("attendance", -1) != ""


def test_validate_and_build_record_duplicate_detection() -> None:
    first = validate_and_build_record(
        {
            "name": "Alice Johnson",
            "studentId": "STU-901",
            "department": "computer science",
            "year": "2nd year",
            "score": "92",
            "satisfaction": "9",
            "studyHours": "20",
            "attendance": "95",
            "feedback": "Great course!\x00",
        }
    )
    assert first.department == "Computer Science"
    assert first.year == "2nd Year"
    assert "\x00" not in first.feedback

    with pytest.raises(ValidationError) as exc_info:
        validate_and_build_record(
            {
                "name": "Bob Duplicate",
                "studentId": "stu-901",
                "department": "Physics",
                "year": "1st Year",
                "score": 80,
                "satisfaction": 8,
                "studyHours": 10,
                "attendance": 90,
            },
            existing_records=[first],
        )
    assert "studentId" in exc_info.value.errors


def test_security_guards(tmp_path: Path) -> None:
    allowed = tmp_path / "data"
    allowed.mkdir()
    safe_file = safe_resolve_path("sample.csv", (allowed,))
    assert safe_file == (allowed / "sample.csv").resolve()

    with pytest.raises(SecurityError):
        safe_resolve_path("../secrets.txt", (allowed,))

    assert sanitize_csv_cell("=CMD|'/C calc'!A0") == "'=CMD|'/C calc'!A0"
    assert sanitize_csv_cell("+SUM(A1:A2)") == "'+SUM(A1:A2)"
    assert sanitize_csv_cell("Normal Text") == "Normal Text"
    assert sanitize_text("Hello\x07World", max_length=5) == "Hello"

    pin_hash = hash_pin("4321")
    assert verify_pin("4321", pin_hash) is True
    assert verify_pin("0000", pin_hash) is False
