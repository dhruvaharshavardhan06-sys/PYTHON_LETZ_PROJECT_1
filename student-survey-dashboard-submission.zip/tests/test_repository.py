"""Tests for Tier 1 persistence (JSON/CSV), corruption fallback, CRUD, PIN protection, and bulk CSV import."""

from __future__ import annotations

from pathlib import Path

import pytest

from survey_dashboard.business.security import SecurityError, hash_pin
from survey_dashboard.business.service import RecordNotFoundError, SurveyService
from survey_dashboard.config import AppConfig
from survey_dashboard.data.repository import FileSurveyRepository


def test_seeding_and_persistence_roundtrip(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    repo = FileSurveyRepository(config)
    service = SurveyService(repo, config)

    records = service.list_records()
    assert len(records) == 35
    assert config.json_path.exists()
    assert config.csv_path.exists()

    # Re-open from disk and ensure records persist without re-seeding duplicates
    service2 = SurveyService(FileSurveyRepository(config), config)
    assert len(service2.list_records()) == 35


def test_json_corruption_falls_back_to_csv(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    repo = FileSurveyRepository(config)
    repo.seed_if_empty(count=10)

    # Corrupt JSON intentionally
    config.json_path.write_text("{corrupted json", encoding="utf-8")
    recovered = repo.load_all()
    assert len(recovered) == 10


def test_crud_and_admin_pin_protection(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path, admin_pin_hash=hash_pin("9999"))
    service = SurveyService(FileSurveyRepository(config), config)

    created = service.add_record(
        {
            "name": "Priya Nair",
            "studentId": "STU-777",
            "department": "Engineering",
            "year": "4th Year",
            "score": 88,
            "satisfaction": 9,
            "studyHours": 25,
            "attendance": 92,
            "feedback": "Strong labs",
        }
    )
    assert created.student_id == "STU-777"
    assert len(service.list_records()) == 36

    updated = service.update_record("STU-777", {"score": 94, "satisfaction": 10})
    assert updated.score == 94
    assert updated.satisfaction == 10

    with pytest.raises(SecurityError):
        service.delete_record("STU-777", pin="0000")

    deleted = service.delete_record("STU-777", pin="9999")
    assert deleted.student_id == "STU-777"
    assert len(service.list_records()) == 35

    with pytest.raises(RecordNotFoundError):
        service.get_record_by_student_id("STU-777")


def test_bulk_csv_import_validation_and_duplicates(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)

    csv_file = config.data_dir / "bulk.csv"
    csv_file.write_text(
        "name,studentId,department,year,score,satisfaction,studyHours,attendance,feedback\n"
        "New Student,STU-801,Physics,1st Year,85,8,15,90,Good\n"
        "Duplicate Student,STU-001,Physics,1st Year,85,8,15,90,Dup\n"
        "Bad Score,STU-802,Physics,1st Year,150,8,15,90,Out of range\n",
        encoding="utf-8",
    )

    summary = service.import_csv("bulk.csv")
    assert summary.added == 1
    assert summary.skipped == 2
    assert len(service.list_records()) == 36
