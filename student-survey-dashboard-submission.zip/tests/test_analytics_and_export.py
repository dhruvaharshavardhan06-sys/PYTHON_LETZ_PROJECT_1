"""Tests for Pandas filtering, aggregations, correlations, threshold warnings, and multi-format export."""

from __future__ import annotations

import json
from pathlib import Path

from survey_dashboard.business.analytics import SurveyAnalyticsEngine
from survey_dashboard.business.service import SurveyService
from survey_dashboard.config import AppConfig
from survey_dashboard.data.repository import FileSurveyRepository
from survey_dashboard.models import FilterCriteria


def test_pandas_filtering_and_summary(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)

    cs_only = service.filter_records(FilterCriteria(department="Computer Science"))
    assert len(cs_only) >= 3
    assert all(r.department == "Computer Science" for r in cs_only)

    high_scorers = service.filter_records(FilterCriteria(min_score=80, max_score=100))
    assert all(80 <= r.score <= 100 for r in high_scorers)

    alice = service.filter_records(FilterCriteria(query="Alice"))
    assert len(alice) == 1
    assert alice[0].name == "Alice Johnson"

    summary = service.get_executive_summary()
    assert summary["totalResponses"] == 35
    assert 0 <= summary["avgScore"] <= 100
    assert "scoreVsSatisfaction" in summary["correlations"]
    assert len(summary["departments"]) == 10
    assert len(summary["years"]) == 5


def test_empty_dataset_analytics(tmp_path: Path) -> None:
    summary = SurveyAnalyticsEngine.compute_executive_summary([])
    assert summary["totalResponses"] == 0
    assert summary["topDepartment"] == "N/A"
    assert SurveyAnalyticsEngine.detect_warnings([]) == []


def test_multi_format_exports_and_csv_injection_defense(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)
    service.add_record(
        {
            "name": "=MaliciousName",
            "studentId": "STU-999",
            "department": "Mathematics",
            "year": "3rd Year",
            "score": 40,
            "satisfaction": 2,
            "studyHours": 5,
            "attendance": 50,
            "feedback": "+1+1",
        }
    )

    csv_path = service.export_data("csv")
    json_path = service.export_data("json")
    md_path = service.export_data("md")
    txt_path = service.export_data("txt")

    assert csv_path.exists()
    csv_text = csv_path.read_text(encoding="utf-8")
    assert "'=MaliciousName" in csv_text
    assert "'+1+1" in csv_text

    parsed_json = json.loads(json_path.read_text(encoding="utf-8"))
    assert len(parsed_json) == 36

    md_text = md_path.read_text(encoding="utf-8")
    assert "Executive Summary Report" in md_text
    assert "Threshold Warning Indicators" in md_text

    txt_text = txt_path.read_text(encoding="utf-8")
    assert "EXECUTIVE SUMMARY REPORT" in txt_text
