"""Tests for Matplotlib chart generation."""

from __future__ import annotations

from pathlib import Path

import pytest

from survey_dashboard.business.service import SurveyService
from survey_dashboard.business.visualizer import SurveyVisualizer, VisualizationError
from survey_dashboard.config import AppConfig
from survey_dashboard.data.repository import FileSurveyRepository


def test_generate_all_matplotlib_charts(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)

    chart_paths = service.generate_charts()
    assert len(chart_paths) == 7
    expected_names = {
        "score_distribution.png",
        "department_responses.png",
        "satisfaction_vs_score.png",
        "study_hours_and_attendance.png",
        "avg_score_by_department.png",
        "year_satisfaction_and_trend.png",
        "executive_dashboard.png",
    }
    assert {p.name for p in chart_paths} == expected_names
    for path in chart_paths:
        assert path.exists()
        assert path.stat().st_size > 1000


def test_visualizer_rejects_empty_dataset(tmp_path: Path) -> None:
    visualizer = SurveyVisualizer(tmp_path / "charts")
    with pytest.raises(VisualizationError):
        visualizer.generate_all_charts([])
