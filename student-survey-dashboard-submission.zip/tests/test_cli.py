"""End-to-end tests for Tier 3 CLI interactive menu and argparse commands."""

from __future__ import annotations

from pathlib import Path

from survey_dashboard.business.service import SurveyService
from survey_dashboard.config import AppConfig
from survey_dashboard.data.repository import FileSurveyRepository
from survey_dashboard.presentation.cli import SurveyCLI, main


def test_cli_non_interactive_flags(tmp_path: Path, capsys) -> None:
    exit_code = main(["--data-dir", str(tmp_path), "--summary", "--charts", "--export", "all"])
    assert exit_code == 0

    captured = capsys.readouterr().out
    assert "EXECUTIVE SUMMARY" in captured
    assert "Generated 7 chart(s)" in captured
    assert (tmp_path / "outputs" / "charts" / "executive_dashboard.png").exists()
    assert (tmp_path / "outputs" / "exports" / "survey_report.md").exists()


def test_cli_interactive_menu_flow(tmp_path: Path) -> None:
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)

    # Simulate: 1 (summary) -> 2 (add entry) -> 4 (filter) -> 0 (exit)
    scripted_inputs = iter([
        "1",
        "2", "Kiran Rao", "STU-555", "1", "3", "91", "9", "24", "96", "Very good",
        "4", "Kiran", "", "", "", "",
        "0",
    ])
    outputs: list[str] = []

    cli = SurveyCLI(
        service=service,
        input_fn=lambda _prompt: next(scripted_inputs),
        output_fn=outputs.append,
    )
    cli.run_interactive()

    joined = "\n".join(outputs)
    assert "Total Responses   : 35" in joined
    assert "Saved record for Kiran Rao (STU-555)" in joined
    assert "Matched 1 record(s):" in joined
    assert "Goodbye!" in joined
