"""Integration tests for Tier 3 Web Presentation Layer (HTTP server & JSON API)."""

from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from pathlib import Path

import pytest

from survey_dashboard.business.service import SurveyService
from survey_dashboard.config import AppConfig
from survey_dashboard.data.repository import FileSurveyRepository
from survey_dashboard.presentation.web import create_server


@pytest.fixture()
def live_web_server(tmp_path: Path):
    config = AppConfig.from_base_dir(tmp_path)
    service = SurveyService(FileSurveyRepository(config), config)
    server = create_server(service=service, host="127.0.0.1", port=0)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}", tmp_path
    server.shutdown()
    server.server_close()


def _http_json(url: str, method: str = "GET", payload: dict | None = None) -> tuple[int, dict]:
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"} if data is not None else {},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def test_web_static_assets_and_api_crud(live_web_server) -> None:
    base_url, _ = live_web_server

    # Static HTML
    with urllib.request.urlopen(f"{base_url}/", timeout=5) as resp:
        html = resp.read().decode("utf-8")
        assert resp.status == 200
        assert "Student Survey Dashboard" in html

    # Health & initial seeded records
    status, health = _http_json(f"{base_url}/api/health")
    assert status == 200
    assert health["records"] == 35

    # Create record
    status, created = _http_json(
        f"{base_url}/api/records",
        method="POST",
        payload={
            "name": "Meera Iyer",
            "studentId": "STU-950",
            "department": "Computer Science",
            "year": "3rd Year",
            "score": 96,
            "satisfaction": 10,
            "studyHours": 28,
            "attendance": 98,
            "feedback": "Excellent",
        },
    )
    assert status == 201
    assert created["record"]["studentId"] == "STU-950"

    # Update record
    status, updated = _http_json(
        f"{base_url}/api/records/STU-950",
        method="PUT",
        payload={"score": 99},
    )
    assert status == 200
    assert updated["record"]["score"] == 99

    # Pandas summary endpoint
    status, summary = _http_json(f"{base_url}/api/summary")
    assert status == 200
    assert summary["totalResponses"] == 36

    # Matplotlib chart generation + PNG retrieval
    status, chart_res = _http_json(f"{base_url}/api/charts", method="POST", payload={})
    assert status == 200
    assert "executive_dashboard.png" in chart_res["charts"]
    with urllib.request.urlopen(f"{base_url}/api/charts/executive_dashboard.png", timeout=5) as img_resp:
        assert img_resp.status == 200
        assert img_resp.headers.get("Content-Type") == "image/png"
        assert len(img_resp.read()) > 1000

    # Delete record
    status, deleted = _http_json(f"{base_url}/api/records/STU-950", method="DELETE")
    assert status == 200
    assert deleted["deleted"]["studentId"] == "STU-950"


def test_web_blocks_path_traversal(live_web_server) -> None:
    base_url, _ = live_web_server
    try:
        urllib.request.urlopen(f"{base_url}/api/charts/../../pyproject.toml", timeout=5)
        pytest.fail("Expected HTTP 403/404 for traversal attempt")
    except urllib.error.HTTPError as exc:
        assert exc.code in (403, 404)
