# Software Requirements Specification (SRS)
## Student Survey Dashboard — Python 3-Tier Application

- **Project ID:** LocalImpact Challenge · Project #100 (Data & Visualization)
- **Team / Student:** `mrv_icb_gp3` (`MRVICB2630003`)
- **Tech Stack:** Python 3.10+, Pandas, Matplotlib, Pytest, Markdown

---

## 1. System Architecture (3-Tier Design)

The application strictly separates concerns into three independent tiers:

```mermaid
flowchart TD
    UI["Tier 3: Presentation Tier (CLI Menu & Argparse)<br/>survey_dashboard/presentation/cli.py"]
    BL["Tier 2: Business Logic Tier<br/>service.py | validators.py | analytics.py | visualizer.py | exporter.py | security.py"]
    DA["Tier 1: Data Access / Persistence Tier<br/>repository.py | seeder.py"]
    ST["Storage: data/survey_records.json & data/survey_records.csv"]

    UI --> BL
    BL --> DA
    DA --> ST
```

### 1.1 Tier 1 — Data Access / Persistence Tier (`survey_dashboard/data/`)
- `SurveyRepository` abstract base class defining `load_all()`, `save_all()`, and `seed_if_empty()`.
- `FileSurveyRepository` implementing atomic writes (`tempfile` + `os.replace`) to JSON (`data/survey_records.json`) and CSV (`data/survey_records.csv`), with automatic fallback recovery.
- `seeder.py` generating 35 deterministic, realistic sample records on first run.

### 1.2 Tier 2 — Business Logic Tier (`survey_dashboard/business/`)
- `validators.py`: Defensive validation for all 8 core survey fields, strict integer range checking, canonical department/year normalization, and case-insensitive duplicate `studentId` rejection.
- `analytics.py`: Pandas DataFrame engine for multi-criteria boolean filtering, department/year `groupby` aggregations, descriptive statistics (mean, median, std, min, max), Pearson correlations, and threshold warning detection.
- `visualizer.py`: Matplotlib (`Agg` backend) chart generator creating 6 standalone analytical PNGs plus a 2×2 composite `executive_dashboard.png`.
- `exporter.py`: Multi-format exporter (`CSV`, `JSON`, `Markdown`, `Plain Text`) with OWASP CSV formula-injection protection.
- `security.py`: Control-character sanitization, `safe_resolve_path` traversal guard, constant-time Admin PIN verification (`hmac.compare_digest`), and append-only `audit.log`.
- `service.py`: `SurveyService` facade coordinating Tier 1 and Tier 2 without any UI coupling.

### 1.3 Tier 3 — Presentation Tier (`survey_dashboard/presentation/`)
- `cli.py`: Interactive menu-driven CLI (Section 4.1) and non-interactive `argparse` flags (`--summary`, `--charts`, `--export`).

---

## 2. Functional Requirements

### Section 4.1 — Interactive CLI Menu
| Option | Action | Backing Tier 2 Method |
|--------|--------|-----------------------|
| `1` | View Dashboard Summary & Warnings | `SurveyService.get_executive_summary()` |
| `2` | Add New Survey Entry | `SurveyService.add_record()` |
| `3` | Browse All Records (Paginated) | `SurveyService.list_records()` |
| `4` | Search & Filter Records (Pandas) | `SurveyService.filter_records()` |
| `5` | Edit Existing Record | `SurveyService.update_record()` |
| `6` | Delete Record | `SurveyService.delete_record()` |
| `7` | View Analytics, Correlations & At-Risk Students | `SurveyService.get_executive_summary()` / `get_at_risk_students()` |
| `8` | Generate Matplotlib Visualizations | `SurveyService.generate_charts()` |
| `9` | Export Data & Reports (CSV/JSON/MD/TXT) | `SurveyService.export_data()` |
| `10` | Bulk Import Records from CSV | `SurveyService.import_csv()` |
| `11` | Reset to Sample Dataset (35 Records) | `SurveyService.reset_to_sample_data()` |
| `0` | Exit | — |

---

## 3. Validation & Threshold Rules

| Field | Rule |
|-------|------|
| `name` | Sanitized string, ≥ 2 characters |
| `studentId` | Unique, 3–15 alphanumeric/hyphen characters (`^[A-Za-z0-9\-]{3,15}$`) |
| `department` | One of 10 valid academic departments |
| `year` | One of `1st Year`, `2nd Year`, `3rd Year`, `4th Year`, `Postgraduate` |
| `score` | Integer `0–100` |
| `satisfaction` | Integer `1–10` |
| `studyHours` | Integer `0–168` |
| `attendance` | Integer `0–100` |

**Threshold Warnings:**
- `LOW_SCORE`: `score < 50`
- `LOW_ATTENDANCE`: `attendance < 60`
- `LOW_SATISFACTION`: `satisfaction <= 3`
