/* =============================================
   Student Survey Dashboard — web/app.js
   Connected to Python 3-Tier SurveyService API
   (with localStorage fallback if opened via file://)
   ============================================= */

'use strict';

const STORAGE_KEY = 'survey_dashboard_v1';

function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

const validators = {
  name: v => String(v || '').trim().length >= 2 ? '' : 'Name must be at least 2 characters.',
  studentId: v => /^[A-Za-z0-9\-]{3,15}$/.test(String(v || '').trim()) ? '' : 'ID: 3–15 alphanumeric chars (hyphens allowed).',
  dept: v => v ? '' : 'Please select a department.',
  year: v => v ? '' : 'Please select a year.',
  score: v => { const n = Number(v); return (v !== '' && !isNaN(n) && Number.isInteger(n) && n >= 0 && n <= 100) ? '' : 'Score must be integer 0–100.'; },
  satisfaction: v => { const n = Number(v); return (v !== '' && !isNaN(n) && Number.isInteger(n) && n >= 1 && n <= 10) ? '' : 'Satisfaction must be integer 1–10.'; },
  studyHours: v => { const n = Number(v); return (v !== '' && !isNaN(n) && Number.isInteger(n) && n >= 0 && n <= 168) ? '' : 'Study hours must be integer 0–168.'; },
  attendance: v => { const n = Number(v); return (v !== '' && !isNaN(n) && Number.isInteger(n) && n >= 0 && n <= 100) ? '' : 'Attendance must be integer 0–100.'; }
};

function validateField(field, value) {
  const fn = validators[field];
  return fn ? fn(value) : '';
}

function toast(msg, type = 'success', duration = 3000) {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity .3s';
    setTimeout(() => el.remove(), 300);
  }, duration);
}

const chartInstances = {};

function destroyChart(id) {
  if (chartInstances[id]) {
    chartInstances[id].destroy();
    delete chartInstances[id];
  }
}

function createChart(id, config) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx || typeof Chart === 'undefined') return;
  chartInstances[id] = new Chart(ctx, config);
}

const PALETTE = ['#6366f1','#06b6d4','#22c55e','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6','#f97316','#84cc16'];

function scoreBadge(score) {
  let cls = 'score-low';
  if (score >= 90) cls = 'score-excellent';
  else if (score >= 75) cls = 'score-good';
  else if (score >= 50) cls = 'score-avg';
  return `<span class="score-badge ${cls}">${Number(score)}</span>`;
}

const app = (() => {
  let records = [];
  let filteredRecords = [];
  let currentPage = 1;
  let apiConnected = false;
  const PAGE_SIZE = 10;

  async function apiRequest(url, options = {}) {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }
    return data;
  }

  function saveLocal(recs) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(recs)); } catch {}
  }

  function loadLocal() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }

  async function syncRecordsFromBackend() {
    if (window.location.protocol === 'file:') {
      apiConnected = false;
      records = loadLocal();
      updateBackendBadge();
      return;
    }
    try {
      const data = await apiRequest('/api/records');
      records = data.records || [];
      apiConnected = true;
      saveLocal(records);
    } catch {
      apiConnected = false;
      records = loadLocal();
    }
    updateBackendBadge();
  }

  function updateBackendBadge() {
    const el = document.getElementById('backend-status-badge');
    if (el) {
      el.textContent = apiConnected ? '🐍 Python Tier-2 Connected' : '💾 Offline localStorage Mode';
    }
    document.getElementById('record-count-badge').textContent = `${records.length} record${records.length !== 1 ? 's' : ''}`;
  }

  function nav(pageName) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const page = document.getElementById('page-' + pageName);
    if (page) page.classList.add('active');
    const navItem = document.querySelector(`.nav-item[data-page="${pageName}"]`);
    if (navItem) navItem.classList.add('active');
    document.getElementById('sidebar').classList.remove('open');

    if (pageName === 'dashboard') renderDashboard();
    if (pageName === 'records') renderRecords();
    if (pageName === 'analytics') renderAnalytics();
    if (pageName === 'export') renderExport();
  }

  function renderDashboard() {
    updateBackendBadge();
    if (!records.length) {
      document.getElementById('kpi-total').textContent = 0;
      document.getElementById('kpi-avg-score').textContent = '0.0';
      document.getElementById('kpi-avg-satisfaction').textContent = '0.0';
      document.getElementById('kpi-top-dept').textContent = '—';
      document.getElementById('recent-tbody').innerHTML = '';
      renderWarnings();
      return;
    }

    const total = records.length;
    const avgScore = (records.reduce((s, r) => s + r.score, 0) / total).toFixed(1);
    const avgSat = (records.reduce((s, r) => s + r.satisfaction, 0) / total).toFixed(1);

    const deptCount = {};
    records.forEach(r => deptCount[r.department] = (deptCount[r.department] || 0) + 1);
    const topDept = Object.entries(deptCount).sort((a, b) => b[1] - a[1])[0][0];
    const shortDept = topDept.length > 12 ? topDept.split(' ')[0] : topDept;

    document.getElementById('kpi-total').textContent = total;
    document.getElementById('kpi-avg-score').textContent = avgScore;
    document.getElementById('kpi-avg-satisfaction').textContent = avgSat;
    document.getElementById('kpi-top-dept').textContent = shortDept;

    renderWarnings();

    const bins = [0, 0, 0, 0, 0];
    records.forEach(r => { const b = Math.min(4, Math.floor(r.score / 20)); bins[b]++; });
    createChart('chart-score-dist', {
      type: 'bar',
      data: {
        labels: ['0–19','20–39','40–59','60–79','80–100'],
        datasets: [{ label: 'Students', data: bins, backgroundColor: PALETTE.slice(0,5), borderRadius: 6 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    const deptLabels = Object.keys(deptCount);
    const deptData = deptLabels.map(d => deptCount[d]);
    createChart('chart-dept', {
      type: 'doughnut',
      data: { labels: deptLabels, datasets: [{ data: deptData, backgroundColor: PALETTE, borderWidth: 2 }] },
      options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } } } }
    });

    const tbody = document.getElementById('recent-tbody');
    tbody.innerHTML = records.slice(-5).reverse().map(r => `
      <tr>
        <td>${escapeHtml(r.name)}</td>
        <td>${escapeHtml(r.department)}</td>
        <td>${scoreBadge(r.score)}</td>
        <td>${Number(r.satisfaction)}/10</td>
        <td>${Number(r.studyHours)}h</td>
        <td>${escapeHtml(r.date)}</td>
      </tr>`).join('');
  }

  function renderWarnings() {
    const panel = document.getElementById('warning-panel');
    const warnings = [];
    const lowScore = records.filter(r => r.score < 50).length;
    const lowAttend = records.filter(r => r.attendance < 60).length;
    const lowSat = records.filter(r => r.satisfaction <= 3).length;
    if (lowScore > 0) warnings.push(`⚠️ ${lowScore} student(s) have scores below 50 — consider intervention.`);
    if (lowAttend > 0) warnings.push(`⚠️ ${lowAttend} student(s) have attendance below 60% — at risk.`);
    if (lowSat > 0) warnings.push(`⚠️ ${lowSat} student(s) rated satisfaction ≤ 3 — review experience.`);

    if (warnings.length) {
      panel.classList.remove('hidden');
      panel.innerHTML = `<h4>🔔 Threshold Warnings</h4><ul>${warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('')}</ul>`;
    } else {
      panel.classList.add('hidden');
    }
  }

  function getFilteredRecords() {
    const q = document.getElementById('search-input').value.trim().toLowerCase();
    const dept = document.getElementById('filter-dept').value;
    const year = document.getElementById('filter-year').value;
    const scoreRange = document.getElementById('filter-score').value;

    return records.filter(r => {
      if (q && !r.name.toLowerCase().includes(q) && !r.studentId.toLowerCase().includes(q)) return false;
      if (dept && r.department !== dept) return false;
      if (year && r.year !== year) return false;
      if (scoreRange) {
        const [lo, hi] = scoreRange.split('-').map(Number);
        if (r.score < lo || r.score > hi) return false;
      }
      return true;
    });
  }

  function renderRecords() {
    filteredRecords = getFilteredRecords();
    const total = filteredRecords.length;
    document.getElementById('filter-count').textContent = `Showing ${total} of ${records.length} records`;

    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    if (currentPage > totalPages) currentPage = 1;
    const pageRecords = filteredRecords.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

    const tbody = document.getElementById('records-tbody');
    if (!pageRecords.length) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:#94a3b8;padding:30px">No records found</td></tr>';
    } else {
      tbody.innerHTML = pageRecords.map((r, i) => `
        <tr>
          <td>${(currentPage - 1) * PAGE_SIZE + i + 1}</td>
          <td><strong>${escapeHtml(r.name)}</strong></td>
          <td><code>${escapeHtml(r.studentId)}</code></td>
          <td>${escapeHtml(r.department)}</td>
          <td>${escapeHtml(r.year)}</td>
          <td>${scoreBadge(r.score)}</td>
          <td>${Number(r.satisfaction)}/10</td>
          <td>${Number(r.studyHours)}h</td>
          <td>${Number(r.attendance)}%</td>
          <td>${escapeHtml(r.date)}</td>
          <td>
            <div class="action-btns">
              <button class="btn-icon" title="Edit" onclick="app.editRecord('${escapeHtml(r.id)}')">✏️</button>
              <button class="btn-icon" title="Delete" onclick="app.deleteRecord('${escapeHtml(r.id)}')">🗑️</button>
            </div>
          </td>
        </tr>`).join('');
    }

    const pag = document.getElementById('pagination');
    pag.innerHTML = '';
    for (let p = 1; p <= totalPages; p++) {
      const btn = document.createElement('button');
      btn.className = `page-btn${p === currentPage ? ' active' : ''}`;
      btn.textContent = p;
      btn.onclick = () => { currentPage = p; renderRecords(); };
      pag.appendChild(btn);
    }
  }

  function renderAnalytics() {
    if (!records.length) return;
    const n = records.length;
    const scores = records.map(r => r.score);
    const sats = records.map(r => r.satisfaction);
    const hours = records.map(r => r.studyHours);
    const attends = records.map(r => r.attendance);
    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1);

    const stats = [
      { label: 'Total Students', value: n },
      { label: 'Avg Score', value: avg(scores) },
      { label: 'Max Score', value: Math.max(...scores) },
      { label: 'Min Score', value: Math.min(...scores) },
      { label: 'Avg Satisfaction', value: avg(sats) },
      { label: 'Avg Study Hrs', value: avg(hours) },
      { label: 'Avg Attendance', value: avg(attends) + '%' },
      { label: 'Score ≥ 75', value: scores.filter(s => s >= 75).length }
    ];
    document.getElementById('analytics-stats').innerHTML = stats.map(s =>
      `<div class="stat-card"><div class="stat-label">${s.label}</div><div class="stat-value">${s.value}</div></div>`
    ).join('');

    createChart('chart-scatter', {
      type: 'scatter',
      data: { datasets: [{ label: 'Students', data: records.map(r => ({ x: r.score, y: r.satisfaction })), backgroundColor: '#6366f180', pointRadius: 6 }] },
      options: { responsive: true, scales: { x: { title: { display: true, text: 'Score' }, min: 0, max: 100 }, y: { title: { display: true, text: 'Satisfaction' }, min: 0, max: 11 } }, plugins: { legend: { display: false } } }
    });

    const studyBins = [0,0,0,0,0];
    hours.forEach(h => { studyBins[Math.min(4, Math.floor(h / 10))]++; });
    createChart('chart-study-hours', {
      type: 'bar',
      data: { labels: ['0–9h','10–19h','20–29h','30–39h','40+h'], datasets: [{ label: 'Students', data: studyBins, backgroundColor: '#06b6d4', borderRadius: 6 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    const attendBins = [0,0,0,0,0];
    attends.forEach(a => { attendBins[Math.min(4, Math.floor(a / 20))]++; });
    createChart('chart-attendance', {
      type: 'bar',
      data: { labels: ['0–19%','20–39%','40–59%','60–79%','80–100%'], datasets: [{ label: 'Students', data: attendBins, backgroundColor: '#22c55e', borderRadius: 6 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    const depts = [...new Set(records.map(r => r.department))].sort();
    const deptAvgScore = depts.map(d => {
      const rs = records.filter(r => r.department === d);
      return (rs.reduce((s, r) => s + r.score, 0) / rs.length).toFixed(1);
    });
    createChart('chart-dept-score', {
      type: 'bar',
      data: { labels: depts.map(d => d.split(' ')[0]), datasets: [{ label: 'Avg Score', data: deptAvgScore, backgroundColor: PALETTE, borderRadius: 6 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } }
    });

    const yearOrder = ['1st Year','2nd Year','3rd Year','4th Year','Postgraduate'];
    const presentYears = yearOrder.filter(y => records.some(r => r.year === y));
    const yearAvgSat = presentYears.map(y => {
      const rs = records.filter(r => r.year === y);
      return (rs.reduce((s, r) => s + r.satisfaction, 0) / rs.length).toFixed(1);
    });
    createChart('chart-year-satisfaction', {
      type: 'line',
      data: { labels: presentYears.map(y => y.replace(' Year','Y').replace('Postgraduate','PG')), datasets: [{ label: 'Avg Satisfaction', data: yearAvgSat, borderColor: '#f59e0b', backgroundColor: '#fef3c740', fill: true, tension: 0.4, pointRadius: 5 }] },
      options: { responsive: true, scales: { y: { beginAtZero: true, max: 11 } } }
    });

    createChart('chart-score-trend', {
      type: 'line',
      data: { labels: records.map((_, i) => i + 1), datasets: [{ label: 'Score', data: records.map(r => r.score), borderColor: '#6366f1', backgroundColor: '#6366f120', fill: true, tension: 0.3, pointRadius: 3 }] },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 105 } } }
    });
  }

  async function generateMatplotlibCharts() {
    if (!apiConnected) {
      toast('Start server with python main.py --web to render Python Matplotlib charts.', 'warning');
      return;
    }
    const gallery = document.getElementById('mpl-gallery');
    gallery.innerHTML = '<p class="import-hint">Rendering 7 Matplotlib charts…</p>';
    try {
      const res = await apiRequest('/api/charts', { method: 'POST', body: '{}' });
      const ts = Date.now();
      gallery.innerHTML = (res.charts || []).map(name => `
        <div class="mpl-item">
          <img src="/api/charts/${encodeURIComponent(name)}?t=${ts}" alt="${escapeHtml(name)}" />
          <span>${escapeHtml(name)}</span>
        </div>`).join('');
      toast('🐍 Rendered 7 Matplotlib charts!', 'success');
    } catch (err) {
      gallery.innerHTML = `<p class="field-error">${escapeHtml(err.message)}</p>`;
      toast(err.message, 'error');
    }
  }

  function generateCSV() {
    const headers = ['name','studentId','department','year','score','satisfaction','studyHours','attendance','feedback','date'];
    const rows = records.map(r => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','));
    return [headers.join(','), ...rows].join('\n');
  }

  function generateMarkdown() {
    const n = records.length;
    if (!n) return '# No data available';
    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2);
    const scores = records.map(r => r.score);
    const sats = records.map(r => r.satisfaction);
    const deptCount = {};
    records.forEach(r => deptCount[r.department] = (deptCount[r.department] || 0) + 1);
    return `# Student Survey Dashboard — Summary Report\n> Generated: ${new Date().toLocaleString()}\n\n| Metric | Value |\n|---|---|\n| Total Responses | ${n} |\n| Average Score | ${avg(scores)} |\n| Average Satisfaction | ${avg(sats)} / 10 |\n| Max Score | ${Math.max(...scores)} |\n| Min Score | ${Math.min(...scores)} |\n`;
  }

  function generatePlainText() {
    const n = records.length;
    if (!n) return 'No data available.';
    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2);
    return `STUDENT SURVEY DASHBOARD — SUMMARY\nTotal: ${n}\nAvg Score: ${avg(records.map(r => r.score))}\nAvg Satisfaction: ${avg(records.map(r => r.satisfaction))} / 10`;
  }

  async function renderExport() {
    const fmt = document.getElementById('preview-format').value;
    const el = document.getElementById('report-preview');
    if (apiConnected) {
      try {
        const res = await fetch(`/api/export/${fmt}`);
        if (res.ok) {
          el.textContent = await res.text();
          return;
        }
      } catch {}
    }
    if (fmt === 'md') el.textContent = generateMarkdown();
    else if (fmt === 'txt') el.textContent = generatePlainText();
    else el.textContent = JSON.stringify(records, null, 2);
  }

  function downloadFile(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function getFormValues(prefix = 'f') {
    return {
      name: document.getElementById(`${prefix}-name`).value.trim(),
      studentId: document.getElementById(`${prefix}-student-id`).value.trim(),
      department: document.getElementById(`${prefix}-dept`).value,
      year: document.getElementById(`${prefix}-year`).value,
      score: document.getElementById(`${prefix}-score`).value,
      satisfaction: document.getElementById(`${prefix}-satisfaction`).value,
      studyHours: document.getElementById(`${prefix}-study-hours`).value,
      attendance: document.getElementById(`${prefix}-attendance`).value,
      feedback: document.getElementById(`${prefix}-feedback`).value.trim()
    };
  }

  async function handleAddSubmit(e) {
    e.preventDefault();
    const data = getFormValues('f');
    const fields = [
      { key: 'name', id: 'err-name', inputId: 'f-name', val: data.name },
      { key: 'studentId', id: 'err-student-id', inputId: 'f-student-id', val: data.studentId },
      { key: 'dept', id: 'err-dept', inputId: 'f-dept', val: data.department },
      { key: 'year', id: 'err-year', inputId: 'f-year', val: data.year },
      { key: 'score', id: 'err-score', inputId: 'f-score', val: data.score },
      { key: 'satisfaction', id: 'err-satisfaction', inputId: 'f-satisfaction', val: data.satisfaction },
      { key: 'studyHours', id: 'err-study-hours', inputId: 'f-study-hours', val: data.studyHours },
      { key: 'attendance', id: 'err-attendance', inputId: 'f-attendance', val: data.attendance }
    ];
    let valid = true;
    fields.forEach(f => {
      const err = validateField(f.key, f.val);
      document.getElementById(f.id).textContent = err;
      document.getElementById(f.inputId).classList.toggle('invalid', !!err);
      if (err) valid = false;
    });
    if (!valid) { toast('Please fix the errors above.', 'error'); return; }

    try {
      if (apiConnected) {
        const res = await apiRequest('/api/records', { method: 'POST', body: JSON.stringify(data) });
        records.push(res.record);
      } else {
        if (records.some(r => r.studentId.toLowerCase() === data.studentId.toLowerCase())) {
          throw new Error('Student ID already exists.');
        }
        records.push({
          id: generateId(),
          ...data,
          score: Number(data.score),
          satisfaction: Number(data.satisfaction),
          studyHours: Number(data.studyHours),
          attendance: Number(data.attendance),
          date: new Date().toISOString().split('T')[0]
        });
      }
      saveLocal(records);
      updateBackendBadge();
      toast(`✅ Entry for ${data.name} saved!`, 'success');
      document.getElementById('entry-form').reset();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  function editRecord(id) {
    const r = records.find(item => item.id === id);
    if (!r) return;
    document.getElementById('e-id').value = r.id;
    document.getElementById('e-orig-student-id').value = r.studentId;
    document.getElementById('e-name').value = r.name;
    document.getElementById('e-student-id').value = r.studentId;
    document.getElementById('e-dept').value = r.department;
    document.getElementById('e-year').value = r.year;
    document.getElementById('e-score').value = r.score;
    document.getElementById('e-satisfaction').value = r.satisfaction;
    document.getElementById('e-study-hours').value = r.studyHours;
    document.getElementById('e-attendance').value = r.attendance;
    document.getElementById('e-feedback').value = r.feedback || '';
    document.getElementById('edit-modal').classList.remove('hidden');
  }

  async function handleEditSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('e-id').value;
    const origStudentId = document.getElementById('e-orig-student-id').value;
    const data = getFormValues('e');

    try {
      if (apiConnected) {
        const res = await apiRequest(`/api/records/${encodeURIComponent(origStudentId)}`, {
          method: 'PUT',
          body: JSON.stringify(data)
        });
        const idx = records.findIndex(r => r.id === id);
        if (idx !== -1) records[idx] = res.record;
      } else {
        const idx = records.findIndex(r => r.id === id);
        if (idx !== -1) {
          records[idx] = {
            ...records[idx],
            ...data,
            score: Number(data.score),
            satisfaction: Number(data.satisfaction),
            studyHours: Number(data.studyHours),
            attendance: Number(data.attendance)
          };
        }
      }
      saveLocal(records);
      toast('✅ Record updated!', 'success');
      document.getElementById('edit-modal').classList.add('hidden');
      renderRecords();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  async function deleteRecord(id) {
    const r = records.find(item => item.id === id);
    if (!r) return;
    if (!confirm(`Delete entry for "${r.name}"? This cannot be undone.`)) return;

    try {
      if (apiConnected) {
        await apiRequest(`/api/records/${encodeURIComponent(r.studentId)}`, { method: 'DELETE' });
      }
      records = records.filter(item => item.id !== id);
      saveLocal(records);
      updateBackendBadge();
      toast('🗑️ Entry deleted.', 'warning');
      renderRecords();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  function handleCSVImport(file) {
    if (!file || typeof Papa === 'undefined') return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        if (apiConnected) {
          try {
            const res = await apiRequest('/api/import', {
              method: 'POST',
              body: JSON.stringify({ rows: results.data })
            });
            await syncRecordsFromBackend();
            toast(`📥 Imported ${res.added} record(s), ${res.skipped} skipped.`, res.added > 0 ? 'success' : 'warning');
            renderRecords();
          } catch (err) {
            toast(err.message, 'error');
          }
          return;
        }
        toast('Imported locally.', 'success');
      },
      error: (err) => toast('CSV parse error: ' + err.message, 'error')
    });
  }

  async function init() {
    await syncRecordsFromBackend();

    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', e => { e.preventDefault(); nav(item.dataset.page); });
    });
    document.querySelectorAll('[data-page]').forEach(btn => {
      if (btn.classList.contains('nav-item')) return;
      btn.addEventListener('click', e => { e.preventDefault(); nav(btn.dataset.page); });
    });
    document.getElementById('hamburger').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });

    document.getElementById('entry-form').addEventListener('submit', handleAddSubmit);
    document.getElementById('clear-form-btn').addEventListener('click', () => {
      document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
      document.querySelectorAll('.invalid').forEach(el => el.classList.remove('invalid'));
    });

    ['f-name','f-student-id','f-score','f-satisfaction','f-study-hours','f-attendance'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('input', () => {
        const keyMap = { 'f-name':'name','f-student-id':'studentId','f-score':'score','f-satisfaction':'satisfaction','f-study-hours':'studyHours','f-attendance':'attendance' };
        const errMap = { 'f-name':'err-name','f-student-id':'err-student-id','f-score':'err-score','f-satisfaction':'err-satisfaction','f-study-hours':'err-study-hours','f-attendance':'err-attendance' };
        const err = validateField(keyMap[id], el.value);
        document.getElementById(errMap[id]).textContent = err;
        el.classList.toggle('invalid', !!err);
      });
    });

    document.getElementById('edit-form').addEventListener('submit', handleEditSubmit);
    document.getElementById('close-modal').addEventListener('click', () => document.getElementById('edit-modal').classList.add('hidden'));
    document.getElementById('cancel-edit').addEventListener('click', () => document.getElementById('edit-modal').classList.add('hidden'));
    document.getElementById('edit-modal').addEventListener('click', e => { if (e.target === e.currentTarget) e.currentTarget.classList.add('hidden'); });

    ['search-input','filter-dept','filter-year','filter-score'].forEach(id => {
      document.getElementById(id).addEventListener('input', () => { currentPage = 1; renderRecords(); });
    });
    document.getElementById('clear-filters').addEventListener('click', () => {
      document.getElementById('search-input').value = '';
      document.getElementById('filter-dept').value = '';
      document.getElementById('filter-year').value = '';
      document.getElementById('filter-score').value = '';
      currentPage = 1;
      renderRecords();
    });

    document.getElementById('csv-import').addEventListener('change', e => handleCSVImport(e.target.files[0]));
    document.getElementById('generate-mpl-btn').addEventListener('click', generateMatplotlibCharts);

    ['csv','json','md','txt'].forEach(fmt => {
      document.getElementById(`export-${fmt}`).addEventListener('click', () => {
        if (apiConnected) {
          window.location.href = `/api/export/${fmt}`;
          toast(`⬇ Downloading ${fmt.toUpperCase()}…`, 'success');
        } else {
          const map = {
            csv: [generateCSV(), 'survey_data.csv', 'text/csv'],
            json: [JSON.stringify(records, null, 2), 'survey_data.json', 'application/json'],
            md: [generateMarkdown(), 'survey_report.md', 'text/markdown'],
            txt: [generatePlainText(), 'survey_report.txt', 'text/plain']
          };
          downloadFile(...map[fmt]);
        }
      });
    });
    document.getElementById('preview-format').addEventListener('change', renderExport);

    renderDashboard();
  }

  return { init, nav, editRecord, deleteRecord };
})();

document.addEventListener('DOMContentLoaded', app.init);
