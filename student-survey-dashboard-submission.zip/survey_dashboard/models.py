"""Domain data models for the Student Survey Dashboard."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date
from typing import Any


@dataclass
class SurveyRecord:
    """Represents a single validated student survey response."""

    id: str
    name: str
    student_id: str
    department: str
    year: str
    score: int
    satisfaction: int
    study_hours: int
    attendance: int
    feedback: str = ""
    date: str = field(default_factory=lambda: date.today().isoformat())

    def to_dict(self) -> dict[str, Any]:
        """Serialize record using camelCase keys compatible with JSON/CSV schemas."""
        return {
            "id": self.id,
            "name": self.name,
            "studentId": self.student_id,
            "department": self.department,
            "year": self.year,
            "score": int(self.score),
            "satisfaction": int(self.satisfaction),
            "studyHours": int(self.study_hours),
            "attendance": int(self.attendance),
            "feedback": self.feedback,
            "date": self.date,
        }

    def to_snake_dict(self) -> dict[str, Any]:
        """Serialize record using Pythonic snake_case keys."""
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "SurveyRecord":
        """Construct a SurveyRecord from either camelCase or snake_case dictionaries."""
        student_id = payload.get("studentId") if "studentId" in payload else payload.get("student_id", "")
        study_hours = payload.get("studyHours") if "studyHours" in payload else payload.get("study_hours", 0)
        return cls(
            id=str(payload.get("id", "")).strip(),
            name=str(payload.get("name", "")).strip(),
            student_id=str(student_id).strip(),
            department=str(payload.get("department", "")).strip(),
            year=str(payload.get("year", "")).strip(),
            score=int(payload.get("score", 0)),
            satisfaction=int(payload.get("satisfaction", 0)),
            study_hours=int(study_hours),
            attendance=int(payload.get("attendance", 0)),
            feedback=str(payload.get("feedback", "") or "").strip(),
            date=str(payload.get("date") or date.today().isoformat()).strip(),
        )


@dataclass(frozen=True)
class FilterCriteria:
    """Query criteria for filtering survey records via Pandas."""

    query: str = ""
    department: str = ""
    year: str = ""
    min_score: int | None = None
    max_score: int | None = None
    min_attendance: int | None = None
    max_satisfaction: int | None = None


@dataclass(frozen=True)
class ThresholdAlert:
    """Represents a threshold breach alert detected across the survey cohort."""

    code: str
    severity: str
    count: int
    message: str


@dataclass(frozen=True)
class ImportSummary:
    """Outcome of a bulk CSV import operation."""

    added: int
    skipped: int
    errors: list[str]
