"""Application configuration, domain constants, and directory paths."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

DEPARTMENTS: tuple[str, ...] = (
    "Computer Science",
    "Mathematics",
    "Physics",
    "Chemistry",
    "Biology",
    "Engineering",
    "Economics",
    "English",
    "History",
    "Psychology",
)

YEARS_OF_STUDY: tuple[str, ...] = (
    "1st Year",
    "2nd Year",
    "3rd Year",
    "4th Year",
    "Postgraduate",
)

SCORE_MIN = 0
SCORE_MAX = 100
SATISFACTION_MIN = 1
SATISFACTION_MAX = 10
STUDY_HOURS_MIN = 0
STUDY_HOURS_MAX = 168
ATTENDANCE_MIN = 0
ATTENDANCE_MAX = 100

WARNING_SCORE_THRESHOLD = 50
WARNING_ATTENDANCE_THRESHOLD = 60
WARNING_SATISFACTION_THRESHOLD = 3

PAGE_SIZE_DEFAULT = 10
MAX_IMPORT_ROWS = 10_000
MAX_FEEDBACK_LENGTH = 500
MAX_NAME_LENGTH = 100


@dataclass(frozen=True)
class AppConfig:
    """Centralized path and security configuration for the dashboard."""

    base_dir: Path
    data_dir: Path
    json_path: Path
    csv_path: Path
    charts_dir: Path
    exports_dir: Path
    audit_log_path: Path
    admin_pin_hash: str | None = None

    @classmethod
    def from_base_dir(cls, base_dir: Path | str | None = None, admin_pin_hash: str | None = None) -> "AppConfig":
        """Build an AppConfig rooted at ``base_dir`` (defaults to project root)."""
        root = Path(base_dir).resolve() if base_dir else Path(__file__).resolve().parent.parent
        data_dir = root / "data"
        outputs_dir = root / "outputs"
        return cls(
            base_dir=root,
            data_dir=data_dir,
            json_path=data_dir / "survey_records.json",
            csv_path=data_dir / "survey_records.csv",
            charts_dir=outputs_dir / "charts",
            exports_dir=outputs_dir / "exports",
            audit_log_path=data_dir / "audit.log",
            admin_pin_hash=admin_pin_hash,
        )

    def ensure_directories(self) -> None:
        """Create required runtime directories if they do not exist."""
        for directory in (self.data_dir, self.charts_dir, self.exports_dir):
            directory.mkdir(parents=True, exist_ok=True)
