"""Deterministic sample dataset generator for first-run seeding."""

from __future__ import annotations

import random
import uuid
from datetime import date, timedelta

from survey_dashboard.config import DEPARTMENTS, YEARS_OF_STUDY
from survey_dashboard.models import SurveyRecord

_SAMPLE_NAMES: tuple[str, ...] = (
    "Alice Johnson", "Bob Smith", "Carol White", "David Lee", "Eva Martinez",
    "Frank Brown", "Grace Kim", "Henry Davis", "Irene Wilson", "Jack Taylor",
    "Karen Anderson", "Liam Thomas", "Mia Jackson", "Noah Harris", "Olivia Martin",
    "Paul Thompson", "Quinn Robinson", "Rachel Clark", "Sam Lewis", "Tina Walker",
    "Uma Hall", "Victor Allen", "Wendy Young", "Xavier Hernandez", "Yara King",
    "Zoe Wright", "Aaron Scott", "Beth Green", "Carl Adams", "Dana Baker",
    "Elena Carter", "Felix Mitchell", "Gina Perez", "Hugo Roberts", "Iris Turner",
)

_SAMPLE_FEEDBACKS: tuple[str, ...] = (
    "Great course material!",
    "Needs more practical sessions.",
    "Excellent professor support.",
    "Lab sessions were very helpful.",
    "More examples needed.",
    "Perfect pacing.",
    "Could use more interactive tools.",
    "Very well-organized curriculum.",
    "Assignments were challenging but fair.",
    "Loved the group projects!",
    "",
)


def generate_record_id() -> str:
    """Generate a compact unique identifier for a survey record."""
    return uuid.uuid4().hex[:12]


def generate_sample_records(count: int = 35, seed: int = 42, reference_date: date | None = None) -> list[SurveyRecord]:
    """Generate ``count`` realistic, reproducible student survey records."""
    rng = random.Random(seed)
    base_date = reference_date or date(2026, 11, 25)
    records: list[SurveyRecord] = []

    for i in range(count):
        name = _SAMPLE_NAMES[i % len(_SAMPLE_NAMES)]
        if i >= len(_SAMPLE_NAMES):
            name = f"{name} {i // len(_SAMPLE_NAMES) + 1}"
        # Correlate study hours & attendance gently with score so analytics insights are meaningful
        study_hours = rng.randint(6, 48)
        attendance = rng.randint(52, 100)
        base_score = int(0.45 * attendance + 0.7 * study_hours + rng.randint(-15, 22))
        score = max(25, min(100, base_score))
        satisfaction = max(1, min(10, round(score / 12) + rng.randint(-1, 2)))

        record_date = (base_date - timedelta(days=(count - i) * 2)).isoformat()
        records.append(
            SurveyRecord(
                id=f"seed_{i + 1:03d}",
                name=name,
                student_id=f"STU-{i + 1:03d}",
                department=DEPARTMENTS[i % len(DEPARTMENTS)],
                year=YEARS_OF_STUDY[i % len(YEARS_OF_STUDY)],
                score=score,
                satisfaction=satisfaction,
                study_hours=study_hours,
                attendance=attendance,
                feedback=_SAMPLE_FEEDBACKS[i % len(_SAMPLE_FEEDBACKS)],
                date=record_date,
            )
        )
    return records
