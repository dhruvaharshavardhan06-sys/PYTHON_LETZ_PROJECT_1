"""Tier 1 — Data Access / Persistence Layer (JSON + CSV Repository)."""

from __future__ import annotations

import csv
import json
import os
import tempfile
from abc import ABC, abstractmethod
from pathlib import Path

from survey_dashboard.config import AppConfig
from survey_dashboard.data.seeder import generate_sample_records
from survey_dashboard.models import SurveyRecord

CSV_HEADERS: tuple[str, ...] = (
    "id",
    "name",
    "studentId",
    "department",
    "year",
    "score",
    "satisfaction",
    "studyHours",
    "attendance",
    "feedback",
    "date",
)


class PersistenceError(RuntimeError):
    """Raised when reading or writing survey persistence files fails."""


class SurveyRepository(ABC):
    """Abstract repository contract separating persistence from business logic."""

    @abstractmethod
    def load_all(self) -> list[SurveyRecord]:
        """Load all survey records from storage."""

    @abstractmethod
    def save_all(self, records: list[SurveyRecord]) -> None:
        """Persist the full collection of survey records."""

    @abstractmethod
    def seed_if_empty(self, count: int = 35) -> list[SurveyRecord]:
        """Populate storage with sample records if no records exist yet."""


def _atomic_write_text(target_path: Path, content: str) -> None:
    """Write ``content`` to ``target_path`` atomically via a temporary file."""
    target_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target_path.stem}_", suffix=".tmp", dir=str(target_path.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, target_path)
    except Exception as exc:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
        raise PersistenceError(f"Failed atomic write to {target_path}: {exc}") from exc


class FileSurveyRepository(SurveyRepository):
    """Persists survey records simultaneously to JSON (primary) and CSV (tabular mirror)."""

    def __init__(self, config: AppConfig) -> None:
        self.config = config
        self.config.ensure_directories()

    def load_all(self) -> list[SurveyRecord]:
        """Load records from JSON, falling back to CSV if JSON is missing or corrupted."""
        if self.config.json_path.exists():
            try:
                raw_text = self.config.json_path.read_text(encoding="utf-8").strip()
                if not raw_text:
                    return []
                payload = json.loads(raw_text)
                if not isinstance(payload, list):
                    raise PersistenceError("JSON root must be a list of survey records.")
                return [SurveyRecord.from_dict(item) for item in payload if isinstance(item, dict)]
            except (json.JSONDecodeError, ValueError, TypeError) as exc:
                # Attempt graceful recovery from CSV mirror if available
                if self.config.csv_path.exists():
                    return self._load_from_csv(self.config.csv_path)
                raise PersistenceError(f"Corrupted JSON store at {self.config.json_path}: {exc}") from exc

        if self.config.csv_path.exists():
            return self._load_from_csv(self.config.csv_path)

        return []

    def _load_from_csv(self, csv_path: Path) -> list[SurveyRecord]:
        """Read survey records from a CSV file."""
        try:
            with csv_path.open("r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                return [SurveyRecord.from_dict(row) for row in reader if row]
        except (OSError, csv.Error, ValueError) as exc:
            raise PersistenceError(f"Failed to read CSV store {csv_path}: {exc}") from exc

    def save_all(self, records: list[SurveyRecord]) -> None:
        """Persist records atomically to both JSON and CSV files."""
        self.config.ensure_directories()
        serialized = [record.to_dict() for record in records]
        json_content = json.dumps(serialized, indent=2, ensure_ascii=False)
        _atomic_write_text(self.config.json_path, json_content)

        # Write tabular CSV mirror
        fd, tmp_name = tempfile.mkstemp(prefix=".survey_csv_", suffix=".tmp", dir=str(self.config.csv_path.parent))
        tmp_path = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(CSV_HEADERS))
                writer.writeheader()
                for row in serialized:
                    writer.writerow({key: row.get(key, "") for key in CSV_HEADERS})
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path, self.config.csv_path)
        except Exception as exc:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise PersistenceError(f"Failed to save CSV mirror {self.config.csv_path}: {exc}") from exc

    def seed_if_empty(self, count: int = 35) -> list[SurveyRecord]:
        """Seed sample records only when storage files do not exist or contain zero records."""
        existing = self.load_all()
        if existing:
            return existing
        seeded = generate_sample_records(count=count)
        self.save_all(seeded)
        return seeded
