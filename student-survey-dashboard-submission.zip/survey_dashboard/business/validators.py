"""Defensive input validation for student survey records and bulk CSV rows."""

from __future__ import annotations

import re
from datetime import date
from typing import Any

from survey_dashboard.business.security import sanitize_text
from survey_dashboard.config import (
    ATTENDANCE_MAX,
    ATTENDANCE_MIN,
    DEPARTMENTS,
    MAX_FEEDBACK_LENGTH,
    MAX_NAME_LENGTH,
    SATISFACTION_MAX,
    SATISFACTION_MIN,
    SCORE_MAX,
    SCORE_MIN,
    STUDY_HOURS_MAX,
    STUDY_HOURS_MIN,
    YEARS_OF_STUDY,
)
from survey_dashboard.data.seeder import generate_record_id
from survey_dashboard.models import SurveyRecord

STUDENT_ID_PATTERN = re.compile(r"^[A-Za-z0-9\-]{3,15}$")
_DEPT_LOOKUP = {d.lower(): d for d in DEPARTMENTS}
_YEAR_LOOKUP = {y.lower(): y for y in YEARS_OF_STUDY}


class ValidationError(ValueError):
    """Raised when one or more survey record fields fail validation."""

    def __init__(self, errors: dict[str, str]) -> None:
        self.errors = errors
        summary = "; ".join(f"{k}: {v}" for k, v in errors.items())
        super().__init__(summary or "Validation failed.")


def _parse_strict_int(raw: Any, field_name: str, low: int, high: int) -> tuple[int | None, str]:
    """Validate and parse an integer within [low, high], rejecting booleans and floats."""
    if isinstance(raw, bool) or raw is None or str(raw).strip() == "":
        return None, f"{field_name} must be an integer between {low} and {high}."
    try:
        if isinstance(raw, float) and not raw.is_integer():
            return None, f"{field_name} must be a whole integer ({low}–{high})."
        value = int(str(raw).strip())
    except (ValueError, TypeError):
        return None, f"{field_name} must be a valid integer ({low}–{high})."
    if value < low or value > high:
        return None, f"{field_name} must be between {low} and {high}."
    return value, ""


def validate_field(field: str, value: Any) -> str:
    """Validate a single field value; return empty string if valid, or error message."""
    if field == "name":
        cleaned = sanitize_text(str(value or ""), max_length=MAX_NAME_LENGTH)
        if len(cleaned) < 2:
            return "Name must be at least 2 characters."
        return ""

    if field == "student_id":
        sid = str(value or "").strip()
        if not STUDENT_ID_PATTERN.match(sid):
            return "Student ID must be 3–15 alphanumeric characters (hyphens allowed)."
        return ""

    if field == "department":
        dept = str(value or "").strip().lower()
        if dept not in _DEPT_LOOKUP:
            return f"Department must be one of: {', '.join(DEPARTMENTS)}."
        return ""

    if field == "year":
        yr = str(value or "").strip().lower()
        if yr not in _YEAR_LOOKUP:
            return f"Year must be one of: {', '.join(YEARS_OF_STUDY)}."
        return ""

    if field == "score":
        _, err = _parse_strict_int(value, "Score", SCORE_MIN, SCORE_MAX)
        return err

    if field == "satisfaction":
        _, err = _parse_strict_int(value, "Satisfaction", SATISFACTION_MIN, SATISFACTION_MAX)
        return err

    if field == "study_hours":
        _, err = _parse_strict_int(value, "Study hours", STUDY_HOURS_MIN, STUDY_HOURS_MAX)
        return err

    if field == "attendance":
        _, err = _parse_strict_int(value, "Attendance", ATTENDANCE_MIN, ATTENDANCE_MAX)
        return err

    return ""


def validate_and_build_record(
    payload: dict[str, Any],
    existing_records: list[SurveyRecord] | None = None,
    ignore_record_id: str | None = None,
) -> SurveyRecord:
    """Validate all fields, check duplicate studentId, and return a sanitized SurveyRecord."""
    errors: dict[str, str] = {}

    raw_name = sanitize_text(str(payload.get("name", "")), max_length=MAX_NAME_LENGTH)
    if err := validate_field("name", raw_name):
        errors["name"] = err

    raw_sid = str(payload.get("studentId") if "studentId" in payload else payload.get("student_id", "")).strip()
    if err := validate_field("student_id", raw_sid):
        errors["studentId"] = err

    raw_dept = str(payload.get("department", "")).strip()
    if err := validate_field("department", raw_dept):
        errors["department"] = err
    canonical_dept = _DEPT_LOOKUP.get(raw_dept.lower(), raw_dept)

    raw_year = str(payload.get("year", "")).strip()
    if err := validate_field("year", raw_year):
        errors["year"] = err
    canonical_year = _YEAR_LOOKUP.get(raw_year.lower(), raw_year)

    score, err = _parse_strict_int(payload.get("score"), "Score", SCORE_MIN, SCORE_MAX)
    if err:
        errors["score"] = err

    satisfaction, err = _parse_strict_int(
        payload.get("satisfaction"), "Satisfaction", SATISFACTION_MIN, SATISFACTION_MAX
    )
    if err:
        errors["satisfaction"] = err

    raw_hours = payload.get("studyHours") if "studyHours" in payload else payload.get("study_hours")
    study_hours, err = _parse_strict_int(raw_hours, "Study hours", STUDY_HOURS_MIN, STUDY_HOURS_MAX)
    if err:
        errors["studyHours"] = err

    attendance, err = _parse_strict_int(payload.get("attendance"), "Attendance", ATTENDANCE_MIN, ATTENDANCE_MAX)
    if err:
        errors["attendance"] = err

    raw_date = str(payload.get("date") or date.today().isoformat()).strip()
    try:
        date.fromisoformat(raw_date)
    except ValueError:
        errors["date"] = "Date must be in ISO format (YYYY-MM-DD)."

    if existing_records and raw_sid and "studentId" not in errors:
        duplicate = any(
            r.student_id.lower() == raw_sid.lower() and r.id != ignore_record_id
            for r in existing_records
        )
        if duplicate:
            errors["studentId"] = f"Student ID '{raw_sid}' already exists."

    if errors:
        raise ValidationError(errors)

    feedback = sanitize_text(str(payload.get("feedback", "") or ""), max_length=MAX_FEEDBACK_LENGTH)
    record_id = str(payload.get("id") or generate_record_id()).strip()

    return SurveyRecord(
        id=record_id,
        name=raw_name,
        student_id=raw_sid,
        department=canonical_dept,
        year=canonical_year,
        score=int(score),  # type: ignore[arg-type]
        satisfaction=int(satisfaction),  # type: ignore[arg-type]
        study_hours=int(study_hours),  # type: ignore[arg-type]
        attendance=int(attendance),  # type: ignore[arg-type]
        feedback=feedback,
        date=raw_date,
    )
