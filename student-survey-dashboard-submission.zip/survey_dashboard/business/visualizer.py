"""Tier 2 — Matplotlib Visualization Engine for Student Survey Analytics."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "student_survey_mplconfig"))

import matplotlib

matplotlib.use("Agg")  # Headless-safe backend for CLI, servers, and CI
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from survey_dashboard.business.analytics import SurveyAnalyticsEngine
from survey_dashboard.config import WARNING_SCORE_THRESHOLD
from survey_dashboard.models import SurveyRecord

PALETTE = [
    "#4f46e5", "#06b6d4", "#22c55e", "#f59e0b", "#ef4444",
    "#8b5cf6", "#ec4899", "#14b8a6", "#f97316", "#84cc16",
]


class VisualizationError(RuntimeError):
    """Raised when chart generation cannot proceed (e.g., empty dataset)."""


class SurveyVisualizer:
    """Generates high-DPI Matplotlib PNG charts from survey records."""

    def __init__(self, charts_dir: Path) -> None:
        self.charts_dir = charts_dir

    def generate_all_charts(self, records: list[SurveyRecord]) -> list[Path]:
        """Generate all 6 individual analytical charts plus a composite executive dashboard."""
        if not records:
            raise VisualizationError("Cannot generate charts: no survey records available.")

        self.charts_dir.mkdir(parents=True, exist_ok=True)
        df = SurveyAnalyticsEngine.to_dataframe(records)
        dept_df = SurveyAnalyticsEngine.department_breakdown(records)
        year_df = SurveyAnalyticsEngine.year_breakdown(records)

        plt.rcParams.update({
            "axes.edgecolor": "#cbd5e1",
            "axes.linewidth": 0.8,
            "font.size": 10,
            "figure.facecolor": "white",
            "axes.facecolor": "#f8fafc",
        })

        generated = [
            self._plot_score_distribution(df),
            self._plot_department_responses(dept_df),
            self._plot_satisfaction_vs_score(df),
            self._plot_study_and_attendance(df),
            self._plot_department_avg_score(dept_df),
            self._plot_year_trend(year_df),
            self._plot_executive_dashboard(df, dept_df, year_df),
        ]
        return generated

    def _save_fig(self, fig: plt.Figure, filename: str) -> Path:
        """Save figure cleanly at 150 DPI and release memory."""
        output_path = self.charts_dir / filename
        fig.tight_layout()
        fig.savefig(output_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        return output_path

    def _plot_score_distribution(self, df: pd.DataFrame) -> Path:
        fig, ax = plt.subplots(figsize=(8, 5))
        bins = [0, 20, 40, 60, 80, 101]
        counts, edges = np.histogram(df["score"], bins=bins)
        labels = ["0–19", "20–39", "40–59", "60–79", "80–100"]
        bars = ax.bar(labels, counts, color=PALETTE[:5], edgecolor="#1e293b", linewidth=0.6)
        ax.bar_label(bars, padding=3, fontsize=9, fontweight="bold")

        mean_score = float(df["score"].mean())
        ax.set_title(f"Academic Score Distribution (n={len(df)}, Mean={mean_score:.1f})", fontweight="bold", pad=12)
        ax.set_xlabel("Score Band")
        ax.set_ylabel("Number of Students")
        ax.grid(axis="y", linestyle="--", alpha=0.4)
        return self._save_fig(fig, "score_distribution.png")

    def _plot_department_responses(self, dept_df: pd.DataFrame) -> Path:
        fig, ax = plt.subplots(figsize=(8, 5))
        colors = [PALETTE[i % len(PALETTE)] for i in range(len(dept_df))]
        wedges, texts, autotexts = ax.pie(
            dept_df["count"],
            labels=dept_df["department"],
            autopct="%1.1f%%",
            startangle=140,
            colors=colors,
            pctdistance=0.78,
            wedgeprops={"width": 0.45, "edgecolor": "white", "linewidth": 1.5},
        )
        for autotext in autotexts:
            autotext.set_fontsize(8)
            autotext.set_fontweight("bold")
        ax.set_title("Survey Responses by Department", fontweight="bold", pad=12)
        return self._save_fig(fig, "department_responses.png")

    def _plot_satisfaction_vs_score(self, df: pd.DataFrame) -> Path:
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.scatter(
            df["score"],
            df["satisfaction"],
            c="#4f46e5",
            alpha=0.75,
            edgecolors="white",
            s=75,
            label="Students",
        )
        if len(df) >= 2 and df["score"].nunique() > 1:
            slope, intercept = np.polyfit(df["score"], df["satisfaction"], 1)
            xs = np.linspace(df["score"].min(), df["score"].max(), 50)
            ax.plot(xs, slope * xs + intercept, color="#ef4444", linestyle="--", linewidth=2, label="Trendline")
            corr = df["score"].corr(df["satisfaction"])
            if pd.notna(corr):
                ax.text(
                    0.03, 0.93, f"Pearson r = {corr:.2f}",
                    transform=ax.transAxes,
                    bbox={"boxstyle": "round,pad=0.3", "facecolor": "#eef2ff", "edgecolor": "#6366f1"},
                    fontsize=9,
                )

        ax.set_title("Satisfaction vs Academic Score", fontweight="bold", pad=12)
        ax.set_xlabel("Academic Score (0–100)")
        ax.set_ylabel("Satisfaction Rating (1–10)")
        ax.set_xlim(0, 105)
        ax.set_ylim(0, 11)
        ax.grid(True, linestyle="--", alpha=0.4)
        ax.legend(loc="lower right")
        return self._save_fig(fig, "satisfaction_vs_score.png")

    def _plot_study_and_attendance(self, df: pd.DataFrame) -> Path:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.8))

        study_bins = [0, 10, 20, 30, 40, 169]
        study_counts, _ = np.histogram(df["studyHours"], bins=study_bins)
        b1 = ax1.bar(["0–9h", "10–19h", "20–29h", "30–39h", "40+h"], study_counts, color="#06b6d4", edgecolor="#0e7490")
        ax1.bar_label(b1, padding=2, fontsize=8)
        ax1.set_title("Weekly Study Hours", fontweight="bold")
        ax1.set_ylabel("Students")
        ax1.grid(axis="y", linestyle="--", alpha=0.4)

        att_bins = [0, 20, 40, 60, 80, 101]
        att_counts, _ = np.histogram(df["attendance"], bins=att_bins)
        b2 = ax2.bar(["0–19%", "20–39%", "40–59%", "60–79%", "80–100%"], att_counts, color="#22c55e", edgecolor="#15803d")
        ax2.bar_label(b2, padding=2, fontsize=8)
        ax2.set_title("Attendance Distribution", fontweight="bold")
        ax2.set_ylabel("Students")
        ax2.grid(axis="y", linestyle="--", alpha=0.4)

        fig.suptitle("Study Habits & Attendance Breakdown", fontweight="bold", y=1.02)
        return self._save_fig(fig, "study_hours_and_attendance.png")

    def _plot_department_avg_score(self, dept_df: pd.DataFrame) -> Path:
        fig, ax = plt.subplots(figsize=(9, 5))
        ordered = dept_df.sort_values("avgScore", ascending=True)
        colors = ["#ef4444" if s < WARNING_SCORE_THRESHOLD else "#4f46e5" for s in ordered["avgScore"]]
        bars = ax.barh(ordered["department"], ordered["avgScore"], color=colors, edgecolor="#1e293b", linewidth=0.5)
        ax.bar_label(bars, fmt="%.1f", padding=4, fontsize=9)
        ax.axvline(WARNING_SCORE_THRESHOLD, color="#f59e0b", linestyle="--", linewidth=1.5, label=f"Threshold ({WARNING_SCORE_THRESHOLD})")
        ax.set_xlim(0, 108)
        ax.set_title("Average Academic Score by Department", fontweight="bold", pad=12)
        ax.set_xlabel("Average Score")
        ax.grid(axis="x", linestyle="--", alpha=0.4)
        ax.legend(loc="lower right")
        return self._save_fig(fig, "avg_score_by_department.png")

    def _plot_year_trend(self, year_df: pd.DataFrame) -> Path:
        fig, ax1 = plt.subplots(figsize=(8.5, 5))
        x = np.arange(len(year_df))
        ax1.plot(x, year_df["avgScore"], marker="o", color="#4f46e5", linewidth=2.5, label="Avg Score (0–100)")
        ax1.set_ylabel("Average Score", color="#4f46e5", fontweight="bold")
        ax1.set_ylim(0, 105)
        ax1.set_xticks(x)
        ax1.set_xticklabels(year_df["year"], rotation=15)
        ax1.grid(True, linestyle="--", alpha=0.4)

        ax2 = ax1.twinx()
        ax2.plot(x, year_df["avgSatisfaction"], marker="s", linestyle="--", color="#f59e0b", linewidth=2.2, label="Avg Satisfaction (1–10)")
        ax2.set_ylabel("Average Satisfaction", color="#d97706", fontweight="bold")
        ax2.set_ylim(0, 11)

        ax1.set_title("Year-wise Academic Score & Satisfaction Trend", fontweight="bold", pad=12)
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")
        return self._save_fig(fig, "year_satisfaction_and_trend.png")

    def _plot_executive_dashboard(self, df: pd.DataFrame, dept_df: pd.DataFrame, year_df: pd.DataFrame) -> Path:
        fig, axes = plt.subplots(2, 2, figsize=(13, 9))
        fig.suptitle("Student Survey Dashboard — Executive Visual Summary", fontsize=14, fontweight="bold", y=0.98)

        # Panel 1: Score Histogram
        ax = axes[0, 0]
        bins = [0, 20, 40, 60, 80, 101]
        counts, _ = np.histogram(df["score"], bins=bins)
        bars = ax.bar(["0–19", "20–39", "40–59", "60–79", "80–100"], counts, color=PALETTE[:5])
        ax.bar_label(bars, padding=2, fontsize=8)
        ax.set_title("Score Distribution", fontweight="bold")
        ax.grid(axis="y", linestyle="--", alpha=0.35)

        # Panel 2: Department Avg Score
        ax = axes[0, 1]
        ordered = dept_df.sort_values("avgScore", ascending=True)
        bars = ax.barh(ordered["department"], ordered["avgScore"], color="#4f46e5")
        ax.bar_label(bars, fmt="%.1f", padding=3, fontsize=8)
        ax.set_xlim(0, 108)
        ax.set_title("Avg Score by Department", fontweight="bold")
        ax.grid(axis="x", linestyle="--", alpha=0.35)

        # Panel 3: Satisfaction vs Score Scatter
        ax = axes[1, 0]
        ax.scatter(df["score"], df["satisfaction"], c="#06b6d4", alpha=0.8, edgecolors="#0f172a", s=50)
        ax.set_title("Satisfaction vs Score", fontweight="bold")
        ax.set_xlabel("Score")
        ax.set_ylabel("Satisfaction")
        ax.set_xlim(0, 105)
        ax.set_ylim(0, 11)
        ax.grid(True, linestyle="--", alpha=0.35)

        # Panel 4: Year-wise Avg Score
        ax = axes[1, 1]
        ax.plot(year_df["year"], year_df["avgScore"], marker="o", color="#22c55e", linewidth=2.2)
        ax.fill_between(range(len(year_df)), year_df["avgScore"], color="#22c55e", alpha=0.15)
        ax.set_title("Year-wise Avg Score Trend", fontweight="bold")
        ax.set_ylim(0, 105)
        ax.tick_params(axis="x", rotation=15)
        ax.grid(True, linestyle="--", alpha=0.35)

        return self._save_fig(fig, "executive_dashboard.png")
