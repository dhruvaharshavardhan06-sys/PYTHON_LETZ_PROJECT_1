"""Tier 2 — Multi-Format Exporter (CSV, JSON, Markdown, Plain Text) with OWASP CSV Injection Defense."""

from __future__ import annotations

import csv
import io
import json
from datetime import datetime, timezone
from pathlib import Path

from survey_dashboard.business.analytics import SurveyAnalyticsEngine
from survey_dashboard.business.security import safe_resolve_path, sanitize_csv_cell
from survey_dashboard.models import SurveyRecord

EXPORT_FIELDS: tuple[str, ...] = (
    "name",
    "studentId",
    "department",
    "year",
    "score",
    "satisfaction",
    "studyHours",
    "attendance",
    "feedback",
    "date",
)


class SurveyExporter:
    """Renders and safely writes survey exports in CSV, JSON, Markdown, and Plain Text."""

    def __init__(self, exports_dir: Path) -> None:
        self.exports_dir = exports_dir

    @staticmethod
    def to_csv_string(records: list[SurveyRecord]) -> str:
        """Render records to CSV with formula-injection neutralization."""
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=list(EXPORT_FIELDS))
        writer.writeheader()
        for record in records:
            raw = record.to_dict()
            safe_row = {
                key: sanitize_csv_cell(raw.get(key, "")) if key in ("name", "studentId", "feedback") else raw.get(key, "")
                for key in EXPORT_FIELDS
            }
            writer.writerow(safe_row)
        return buffer.getvalue()

    @staticmethod
    def to_json_string(records: list[SurveyRecord]) -> str:
        """Render records to formatted JSON."""
        return json.dumps([r.to_dict() for r in records], indent=2, ensure_ascii=False)

    @staticmethod
    def to_markdown_report(records: list[SurveyRecord]) -> str:
        """Generate an executive audit-style Markdown summary report."""
        if not records:
            return "# Student Survey Dashboard — Summary Report\n\n> No survey records available.\n"

        summary = SurveyAnalyticsEngine.compute_executive_summary(records)
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        corr = summary["correlations"]

        lines = [
            "# Student Survey Dashboard — Executive Summary Report",
            f"> Generated: {timestamp}",
            "",
            "## Key Performance Indicators",
            "",
            "| Metric | Value |",
            "|--------|-------|",
            f"| Total Responses | {summary['totalResponses']} |",
            f"| Average Score | {summary['avgScore']} / 100 |",
            f"| Median Score | {summary['medianScore']} / 100 |",
            f"| Score Std Dev | {summary['stdScore']} |",
            f"| Min / Max Score | {summary['minScore']} / {summary['maxScore']} |",
            f"| Average Satisfaction | {summary['avgSatisfaction']} / 10 |",
            f"| Average Study Hours | {summary['avgStudyHours']} hrs/week |",
            f"| Average Attendance | {summary['avgAttendance']}% |",
            f"| High Achievers (Score >= 75) | {summary['highAchieversCount']} |",
            f"| Top Department (by responses) | {summary['topDepartment']} |",
            "",
            "## Statistical Correlations (Pearson r)",
            "",
            f"- Score vs Satisfaction: **{corr.get('scoreVsSatisfaction', 0.0)}**",
            f"- Score vs Study Hours: **{corr.get('scoreVsStudyHours', 0.0)}**",
            f"- Score vs Attendance: **{corr.get('scoreVsAttendance', 0.0)}**",
            "",
            "## Department Breakdown",
            "",
            "| Department | Responses | Avg Score | Avg Satisfaction | Avg Study Hrs | Avg Attendance |",
            "|------------|-----------|-----------|------------------|---------------|----------------|",
        ]
        for dept in summary["departments"]:
            lines.append(
                f"| {dept['department']} | {dept['count']} | {dept['avgScore']} | "
                f"{dept['avgSatisfaction']} | {dept['avgStudyHours']}h | {dept['avgAttendance']}% |"
            )

        lines.extend(["", "## Year-wise Progression", "", "| Year | Responses | Avg Score | Avg Satisfaction |", "|------|-----------|-----------|------------------|"])
        for yr in summary["years"]:
            lines.append(f"| {yr['year']} | {yr['count']} | {yr['avgScore']} | {yr['avgSatisfaction']} |")

        lines.extend(["", "## Threshold Warning Indicators", ""])
        if summary["warnings"]:
            for warn in summary["warnings"]:
                lines.append(f"- **[{warn['code']}]** {warn['message']}")
        else:
            lines.append("- All cohort metrics are within healthy thresholds.")

        lines.append("")
        return "\n".join(lines)

    @staticmethod
    def to_text_report(records: list[SurveyRecord]) -> str:
        """Generate a clean plain-text executive summary report."""
        if not records:
            return "Student Survey Dashboard — No survey records available.\n"

        summary = SurveyAnalyticsEngine.compute_executive_summary(records)
        divider = "=" * 64
        sub = "-" * 64
        lines = [
            divider,
            " STUDENT SURVEY DASHBOARD — EXECUTIVE SUMMARY REPORT",
            divider,
            f"Total Responses   : {summary['totalResponses']}",
            f"Average Score     : {summary['avgScore']} / 100 (Median: {summary['medianScore']})",
            f"Min / Max Score   : {summary['minScore']} / {summary['maxScore']}",
            f"Avg Satisfaction  : {summary['avgSatisfaction']} / 10",
            f"Avg Study Hours   : {summary['avgStudyHours']} hrs/week",
            f"Avg Attendance    : {summary['avgAttendance']}%",
            f"Top Department    : {summary['topDepartment']}",
            sub,
            " DEPARTMENT BREAKDOWN",
            sub,
        ]
        for dept in summary["departments"]:
            lines.append(
                f"  {dept['department']:<20} Count: {dept['count']:<4} AvgScore: {dept['avgScore']:<6} AvgSat: {dept['avgSatisfaction']}"
            )
        lines.extend([sub, " THRESHOLD WARNINGS", sub])
        if summary["warnings"]:
            for warn in summary["warnings"]:
                lines.append(f"  [!] {warn['message']}")
        else:
            lines.append("  [OK] All metrics within healthy thresholds.")
        lines.append(divider)
        return "\n".join(lines) + "\n"

    def export_file(self, records: list[SurveyRecord], fmt: str, filename: str | None = None) -> Path:
        """Export survey data or summary report into ``self.exports_dir`` safely."""
        fmt_norm = fmt.strip().lower()
        generators = {
            "csv": (self.to_csv_string, "survey_data.csv"),
            "json": (self.to_json_string, "survey_data.json"),
            "md": (self.to_markdown_report, "survey_report.md"),
            "txt": (self.to_text_report, "survey_report.txt"),
        }
        if fmt_norm not in generators:
            raise ValueError(f"Unsupported export format '{fmt}'. Choose from: {', '.join(generators)}.")

        fn, default_name = generators[fmt_norm]
        target_name = filename or default_name
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        resolved = safe_resolve_path(target_name, (self.exports_dir,))
        content = fn(records)
        resolved.write_text(content, encoding="utf-8")
        return resolved
