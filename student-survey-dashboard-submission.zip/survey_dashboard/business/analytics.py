"""Tier 2 — Pandas-powered Filtering, Aggregation, Correlation, and Executive Summary Engine."""

from __future__ import annotations

from typing import Any

import pandas as pd

from survey_dashboard.config import (
    WARNING_ATTENDANCE_THRESHOLD,
    WARNING_SATISFACTION_THRESHOLD,
    WARNING_SCORE_THRESHOLD,
    YEARS_OF_STUDY,
)
from survey_dashboard.models import FilterCriteria, SurveyRecord, ThresholdAlert

EMPTY_COLUMNS = [
    "id",
    "name",
    "studentId",
    "department",
    "year",
    "score",
    "satisfaction",
    "studyHours",
    "attendance",
    "feedback",
    "date",
]


class SurveyAnalyticsEngine:
    """Converts SurveyRecord collections into Pandas DataFrames for filtering and statistical insights."""

    @staticmethod
    def to_dataframe(records: list[SurveyRecord]) -> pd.DataFrame:
        """Build a typed Pandas DataFrame from ``records``."""
        if not records:
            return pd.DataFrame(columns=EMPTY_COLUMNS)
        df = pd.DataFrame([r.to_dict() for r in records])
        for col in ("score", "satisfaction", "studyHours", "attendance"):
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)
        return df

    @classmethod
    def filter_dataframe(cls, records: list[SurveyRecord], criteria: FilterCriteria) -> pd.DataFrame:
        """Apply multi-criteria Pandas boolean indexing over ``records``."""
        df = cls.to_dataframe(records)
        if df.empty:
            return df

        mask = pd.Series(True, index=df.index)

        if criteria.query.strip():
            q = criteria.query.strip()
            name_match = df["name"].str.contains(q, case=False, na=False, regex=False)
            id_match = df["studentId"].str.contains(q, case=False, na=False, regex=False)
            mask &= name_match | id_match

        if criteria.department.strip():
            mask &= df["department"].str.lower() == criteria.department.strip().lower()

        if criteria.year.strip():
            mask &= df["year"].str.lower() == criteria.year.strip().lower()

        if criteria.min_score is not None:
            mask &= df["score"] >= criteria.min_score

        if criteria.max_score is not None:
            mask &= df["score"] <= criteria.max_score

        if criteria.min_attendance is not None:
            mask &= df["attendance"] >= criteria.min_attendance

        if criteria.max_satisfaction is not None:
            mask &= df["satisfaction"] <= criteria.max_satisfaction

        return df.loc[mask].reset_index(drop=True)

    @classmethod
    def filter_records(cls, records: list[SurveyRecord], criteria: FilterCriteria) -> list[SurveyRecord]:
        """Return matching SurveyRecord objects filtered via Pandas."""
        filtered_df = cls.filter_dataframe(records, criteria)
        if filtered_df.empty:
            return []
        return [SurveyRecord.from_dict(row) for row in filtered_df.to_dict(orient="records")]

    @classmethod
    def detect_warnings(cls, records: list[SurveyRecord]) -> list[ThresholdAlert]:
        """Evaluate threshold warning indicators on the cohort."""
        df = cls.to_dataframe(records)
        if df.empty:
            return []

        alerts: list[ThresholdAlert] = []
        low_score_cnt = int((df["score"] < WARNING_SCORE_THRESHOLD).sum())
        if low_score_cnt > 0:
            alerts.append(
                ThresholdAlert(
                    code="LOW_SCORE",
                    severity="WARNING",
                    count=low_score_cnt,
                    message=f"{low_score_cnt} student(s) scored below {WARNING_SCORE_THRESHOLD} — consider academic intervention.",
                )
            )

        low_att_cnt = int((df["attendance"] < WARNING_ATTENDANCE_THRESHOLD).sum())
        if low_att_cnt > 0:
            alerts.append(
                ThresholdAlert(
                    code="LOW_ATTENDANCE",
                    severity="WARNING",
                    count=low_att_cnt,
                    message=f"{low_att_cnt} student(s) have attendance below {WARNING_ATTENDANCE_THRESHOLD}% — at risk.",
                )
            )

        low_sat_cnt = int((df["satisfaction"] <= WARNING_SATISFACTION_THRESHOLD).sum())
        if low_sat_cnt > 0:
            alerts.append(
                ThresholdAlert(
                    code="LOW_SATISFACTION",
                    severity="WARNING",
                    count=low_sat_cnt,
                    message=f"{low_sat_cnt} student(s) rated satisfaction <= {WARNING_SATISFACTION_THRESHOLD} — review experience.",
                )
            )
        return alerts

    @classmethod
    def identify_at_risk_students(cls, records: list[SurveyRecord]) -> pd.DataFrame:
        """Return a Pandas DataFrame of students breaching one or more risk thresholds."""
        df = cls.to_dataframe(records)
        if df.empty:
            return df
        risk_mask = (
            (df["score"] < WARNING_SCORE_THRESHOLD)
            | (df["attendance"] < WARNING_ATTENDANCE_THRESHOLD)
            | (df["satisfaction"] <= WARNING_SATISFACTION_THRESHOLD)
        )
        at_risk = df.loc[risk_mask].copy()
        if at_risk.empty:
            return at_risk
        at_risk["riskFlags"] = (
            (at_risk["score"] < WARNING_SCORE_THRESHOLD).astype(int)
            + (at_risk["attendance"] < WARNING_ATTENDANCE_THRESHOLD).astype(int)
            + (at_risk["satisfaction"] <= WARNING_SATISFACTION_THRESHOLD).astype(int)
        )
        return at_risk.sort_values(by=["riskFlags", "score"], ascending=[False, True]).reset_index(drop=True)

    @classmethod
    def department_breakdown(cls, records: list[SurveyRecord]) -> pd.DataFrame:
        """Compute grouped Pandas statistics per academic department."""
        df = cls.to_dataframe(records)
        if df.empty:
            return pd.DataFrame(columns=["department", "count", "avgScore", "avgSatisfaction", "avgStudyHours", "avgAttendance"])

        grouped = (
            df.groupby("department", as_index=False)
            .agg(
                count=("id", "count"),
                avgScore=("score", "mean"),
                avgSatisfaction=("satisfaction", "mean"),
                avgStudyHours=("studyHours", "mean"),
                avgAttendance=("attendance", "mean"),
            )
            .sort_values(by=["count", "avgScore"], ascending=[False, False])
            .reset_index(drop=True)
        )
        for col in ("avgScore", "avgSatisfaction", "avgStudyHours", "avgAttendance"):
            grouped[col] = grouped[col].round(2)
        return grouped

    @classmethod
    def year_breakdown(cls, records: list[SurveyRecord]) -> pd.DataFrame:
        """Compute grouped Pandas statistics per year of study in logical order."""
        df = cls.to_dataframe(records)
        if df.empty:
            return pd.DataFrame(columns=["year", "count", "avgScore", "avgSatisfaction"])

        grouped = (
            df.groupby("year", as_index=False)
            .agg(
                count=("id", "count"),
                avgScore=("score", "mean"),
                avgSatisfaction=("satisfaction", "mean"),
            )
        )
        order_map = {year: idx for idx, year in enumerate(YEARS_OF_STUDY)}
        grouped["_order"] = grouped["year"].map(lambda y: order_map.get(y, 99))
        grouped = grouped.sort_values("_order").drop(columns="_order").reset_index(drop=True)
        grouped["avgScore"] = grouped["avgScore"].round(2)
        grouped["avgSatisfaction"] = grouped["avgSatisfaction"].round(2)
        return grouped

    @classmethod
    def compute_executive_summary(cls, records: list[SurveyRecord]) -> dict[str, Any]:
        """Compute comprehensive KPIs, correlations, breakdowns, and warnings."""
        df = cls.to_dataframe(records)
        if df.empty:
            return {
                "totalResponses": 0,
                "avgScore": 0.0,
                "medianScore": 0.0,
                "stdScore": 0.0,
                "minScore": 0,
                "maxScore": 0,
                "avgSatisfaction": 0.0,
                "avgStudyHours": 0.0,
                "avgAttendance": 0.0,
                "highAchieversCount": 0,
                "topDepartment": "N/A",
                "correlations": {},
                "departments": [],
                "years": [],
                "warnings": [],
            }

        dept_df = cls.department_breakdown(records)
        year_df = cls.year_breakdown(records)
        top_dept = str(dept_df.iloc[0]["department"]) if not dept_df.empty else "N/A"

        def _safe_corr(col_a: str, col_b: str) -> float:
            if len(df) < 2 or df[col_a].nunique() < 2 or df[col_b].nunique() < 2:
                return 0.0
            val = df[col_a].corr(df[col_b])
            return round(float(val), 3) if pd.notna(val) else 0.0

        std_val = df["score"].std(ddof=1)
        return {
            "totalResponses": int(len(df)),
            "avgScore": round(float(df["score"].mean()), 2),
            "medianScore": round(float(df["score"].median()), 2),
            "stdScore": round(float(std_val), 2) if pd.notna(std_val) else 0.0,
            "minScore": int(df["score"].min()),
            "maxScore": int(df["score"].max()),
            "avgSatisfaction": round(float(df["satisfaction"].mean()), 2),
            "avgStudyHours": round(float(df["studyHours"].mean()), 2),
            "avgAttendance": round(float(df["attendance"].mean()), 2),
            "highAchieversCount": int((df["score"] >= 75).sum()),
            "topDepartment": top_dept,
            "correlations": {
                "scoreVsSatisfaction": _safe_corr("score", "satisfaction"),
                "scoreVsStudyHours": _safe_corr("score", "studyHours"),
                "scoreVsAttendance": _safe_corr("score", "attendance"),
            },
            "departments": dept_df.to_dict(orient="records"),
            "years": year_df.to_dict(orient="records"),
            "warnings": [
                {"code": w.code, "severity": w.severity, "count": w.count, "message": w.message}
                for w in cls.detect_warnings(records)
            ],
        }
