"""Security utilities: input sanitization, path traversal defense, CSV formula guard, PIN verification, and audit logging."""

from __future__ import annotations

import hashlib
import hmac
import re
from datetime import datetime, timezone
from pathlib import Path

_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


class SecurityError(ValueError):
    """Raised when a security policy (path boundary, auth, or sanitization) is violated."""


def sanitize_text(value: str, max_length: int = 500) -> str:
    """Strip unsafe control characters and bound text length."""
    cleaned = _CONTROL_CHARS_RE.sub("", value or "").strip()
    if len(cleaned) > max_length:
        cleaned = cleaned[:max_length].rstrip()
    return cleaned


def sanitize_csv_cell(value: object) -> str:
    """Neutralize CSV/Excel formula injection payloads (OWASP CSV Injection defense)."""
    text = str(value if value is not None else "")
    if text and text[0] in _FORMULA_PREFIXES:
        return "'" + text
    return text


def safe_resolve_path(user_path: str | Path, allowed_dirs: tuple[Path, ...]) -> Path:
    """Resolve ``user_path`` and verify it resides inside one of ``allowed_dirs``."""
    candidate = Path(user_path)
    if not candidate.is_absolute():
        # Relative paths are anchored to the first allowed directory
        candidate = allowed_dirs[0] / candidate
    resolved = candidate.resolve()

    for base in allowed_dirs:
        base_resolved = base.resolve()
        try:
            resolved.relative_to(base_resolved)
            return resolved
        except ValueError:
            continue

    raise SecurityError(f"Access denied: '{user_path}' resolves outside allowed directories.")


def hash_pin(pin: str, salt: str = "survey_dash_v1") -> str:
    """Compute a salted SHA-256 hash for an optional operator PIN."""
    return hashlib.sha256(f"{salt}:{pin}".encode("utf-8")).hexdigest()


def verify_pin(pin: str, expected_hash: str, salt: str = "survey_dash_v1") -> bool:
    """Constant-time PIN verification."""
    candidate_hash = hash_pin(pin, salt=salt)
    return hmac.compare_digest(candidate_hash, expected_hash)


class AuditLogger:
    """Append-only security and mutation audit logger."""

    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path

    def log(self, action: str, detail: str, actor: str = "cli-user") -> None:
        """Append a UTC-timestamped audit entry."""
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        safe_detail = sanitize_text(detail, max_length=250).replace("\n", " ")
        entry = f"{timestamp} | actor={actor} | action={action} | {safe_detail}\n"
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(entry)
