"""Tier 2 — Application Service Facade coordinating Persistence, Validation, Analytics, Visualization, and Security."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from survey_dashboard.business.analytics import SurveyAnalyticsEngine
from survey_dashboard.business.exporter import SurveyExporter
from survey_dashboard.business.security import (
    AuditLogger,
    SecurityError,
    safe_resolve_path,
    verify_pin,
)
from survey_dashboard.business.validators import validate_and_build_record
from survey_dashboard.business.visualizer import SurveyVisualizer
from survey_dashboard.config import MAX_IMPORT_ROWS, AppConfig
from survey_dashboard.data.repository import SurveyRepository
from survey_dashboard.data.seeder import generate_sample_records
from survey_dashboard.models import FilterCriteria, ImportSummary, SurveyRecord, ThresholdAlert


class RecordNotFoundError(LookupError):
    """Raised when a target survey record cannot be located."""


class SurveyService:
    """Core Business Logic Tier facade used by the CLI Presentation Tier and tests."""

    def __init__(self, repository: SurveyRepository, config: AppConfig) -> None:
        self.repository = repository
        self.config = config
        self.config.ensure_directories()
        self.exporter = SurveyExporter(self.config.exports_dir)
        self.visualizer = SurveyVisualizer(self.config.charts_dir)
        self.audit = AuditLogger(self.config.audit_log_path)
        self._records: list[SurveyRecord] = self.repository.seed_if_empty()

    def _require_admin_pin(self, pin: str | None) -> None:
        """Enforce optional operator PIN for destructive actions when configured."""
        if self.config.admin_pin_hash is None:
            return
        if not pin or not verify_pin(pin, self.config.admin_pin_hash):
            self.audit.log("AUTH_FAILED", "Invalid or missing admin PIN for protected action")
            raise SecurityError("Authentication required: invalid or missing Admin PIN.")

    def list_records(self) -> list[SurveyRecord]:
        """Return a shallow copy of all stored survey records."""
        return list(self._records)

    def get_record_by_student_id(self, student_id: str) -> SurveyRecord:
        """Look up a record by Student ID (case-insensitive)."""
        target = student_id.strip().lower()
        for record in self._records:
            if record.student_id.lower() == target:
                return record
        raise RecordNotFoundError(f"No survey record found for Student ID '{student_id}'.")

    def add_record(self, payload: dict[str, Any]) -> SurveyRecord:
        """Validate, insert, persist, and audit a new survey record."""
        record = validate_and_build_record(payload, existing_records=self._records)
        self._records.append(record)
        self.repository.save_all(self._records)
        self.audit.log("CREATE", f"Added studentId={record.student_id} dept={record.department} score={record.score}")
        return record

    def update_record(self, student_id: str, updates: dict[str, Any]) -> SurveyRecord:
        """Validate and update an existing record identified by ``student_id``."""
        existing = self.get_record_by_student_id(student_id)
        merged = existing.to_dict()
        merged.update({k: v for k, v in updates.items() if v is not None})
        merged["id"] = existing.id

        updated = validate_and_build_record(
            merged,
            existing_records=self._records,
            ignore_record_id=existing.id,
        )
        idx = self._records.index(existing)
        self._records[idx] = updated
        self.repository.save_all(self._records)
        self.audit.log("UPDATE", f"Updated studentId={updated.student_id} score={updated.score}")
        return updated

    def delete_record(self, student_id: str, pin: str | None = None) -> SurveyRecord:
        """Delete a record by Student ID (enforces Admin PIN if configured)."""
        self._require_admin_pin(pin)
        existing = self.get_record_by_student_id(student_id)
        self._records = [r for r in self._records if r.id != existing.id]
        self.repository.save_all(self._records)
        self.audit.log("DELETE", f"Deleted studentId={existing.student_id}")
        return existing

    def reset_to_sample_data(self, count: int = 35, pin: str | None = None) -> list[SurveyRecord]:
        """Reset storage to ``count`` seeded sample records."""
        self._require_admin_pin(pin)
        self._records = generate_sample_records(count=count)
        self.repository.save_all(self._records)
        self.audit.log("RESET_SEED", f"Reset dataset to {count} sample records")
        return list(self._records)

    def filter_records(self, criteria: FilterCriteria) -> list[SurveyRecord]:
        """Filter records using Pandas boolean indexing."""
        return SurveyAnalyticsEngine.filter_records(self._records, criteria)

    def get_executive_summary(self) -> dict[str, Any]:
        """Return KPIs, correlations, breakdowns, and warnings."""
        return SurveyAnalyticsEngine.compute_executive_summary(self._records)

    def get_warnings(self) -> list[ThresholdAlert]:
        """Return active threshold warning alerts."""
        return SurveyAnalyticsEngine.detect_warnings(self._records)

    def get_at_risk_students(self) -> list[dict[str, Any]]:
        """Return at-risk student rows sorted by severity."""
        df = SurveyAnalyticsEngine.identify_at_risk_students(self._records)
        return df.to_dict(orient="records") if not df.empty else []

    def generate_charts(self) -> list[Path]:
        """Generate all Matplotlib charts and log the export."""
        paths = self.visualizer.generate_all_charts(self._records)
        self.audit.log("CHARTS", f"Generated {len(paths)} charts in {self.config.charts_dir.name}")
        return paths

    def export_data(self, fmt: str, filename: str | None = None) -> Path:
        """Export survey data or report to ``fmt`` ('csv', 'json', 'md', 'txt')."""
        out_path = self.exporter.export_file(self._records, fmt=fmt, filename=filename)
        self.audit.log("EXPORT", f"Exported format={fmt} file={out_path.name}")
        return out_path

    def import_csv(self, csv_file: str | Path, allowed_dirs: tuple[Path, ...] | None = None) -> ImportSummary:
        """Safely import and validate records from a CSV file inside allowed directories."""
        search_dirs = allowed_dirs or (self.config.data_dir, self.config.exports_dir, self.config.base_dir)
        resolved_path = safe_resolve_path(csv_file, search_dirs)
        if not resolved_path.exists() or not resolved_path.is_file():
            raise FileNotFoundError(f"CSV file not found: {resolved_path}")

        added = 0
        skipped = 0
        errors: list[str] = []

        with resolved_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise ValueError("CSV file is empty or missing a header row.")

            for row_num, raw_row in enumerate(reader, start=2):
                if row_num - 1 > MAX_IMPORT_ROWS:
                    errors.append(f"Row {row_num}: Exceeded max import limit ({MAX_IMPORT_ROWS}).")
                    break

                normalized = {k.strip().lower(): (v.strip() if isinstance(v, str) else v) for k, v in raw_row.items() if k}
                payload = {
                    "name": normalized.get("name", ""),
                    "studentId": normalized.get("studentid") or normalized.get("student_id") or normalized.get("student id", ""),
                    "department": normalized.get("department", ""),
                    "year": normalized.get("year", ""),
                    "score": normalized.get("score", ""),
                    "satisfaction": normalized.get("satisfaction", ""),
                    "studyHours": normalized.get("studyhours") or normalized.get("study_hours") or normalized.get("study hours", ""),
                    "attendance": normalized.get("attendance", ""),
                    "feedback": normalized.get("feedback", ""),
                    "date": normalized.get("date") or None,
                }
                try:
                    rec = validate_and_build_record(payload, existing_records=self._records)
                    self._records.append(rec)
                    added += 1
                except Exception as exc:
                    skipped += 1
                    errors.append(f"Row {row_num}: {exc}")

        if added > 0:
            self.repository.save_all(self._records)
        self.audit.log("IMPORT_CSV", f"file={resolved_path.name} added={added} skipped={skipped}")
        return ImportSummary(added=added, skipped=skipped, errors=errors)
