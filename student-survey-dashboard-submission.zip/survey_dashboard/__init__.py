"""Student Survey Dashboard — 3-Tier Python Application."""

__version__ = "1.0.0"
__author__ = "mrv_icb_gp3"
