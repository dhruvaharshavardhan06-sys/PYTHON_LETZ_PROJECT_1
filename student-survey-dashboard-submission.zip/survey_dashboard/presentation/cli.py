"""Tier 3 — Presentation Layer: Interactive Section 4.1 CLI Menu and Non-Interactive Command Runner."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Callable

from survey_dashboard.business.security import SecurityError, hash_pin
from survey_dashboard.business.service import RecordNotFoundError, SurveyService
from survey_dashboard.business.validators import ValidationError, validate_field
from survey_dashboard.business.visualizer import VisualizationError
from survey_dashboard.config import DEPARTMENTS, PAGE_SIZE_DEFAULT, YEARS_OF_STUDY, AppConfig
from survey_dashboard.data.repository import FileSurveyRepository, PersistenceError
from survey_dashboard.models import FilterCriteria, SurveyRecord


class SurveyCLI:
    """Menu-driven Command-Line Interface for the Student Survey Dashboard."""

    def __init__(
        self,
        service: SurveyService,
        input_fn: Callable[[str], str] = input,
        output_fn: Callable[[str], None] = print,
    ) -> None:
        self.service = service
        self._input = input_fn
        self._out = output_fn

    def _prompt(self, label: str) -> str:
        return self._input(label).strip()

    def _prompt_validated(self, label: str, field_name: str) -> str:
        """Prompt repeatedly until field validation succeeds or user enters 'cancel'."""
        while True:
            val = self._prompt(label)
            if val.lower() == "cancel":
                raise InterruptedError("Action cancelled by user.")
            err = validate_field(field_name, val)
            if not err:
                return val
            self._out(f"  [Invalid] {err} (or type 'cancel' to abort)")

    def _prompt_choice(self, title: str, options: tuple[str, ...]) -> str:
        """Display numbered options and return the selected canonical option string."""
        self._out(f"  {title}:")
        for idx, opt in enumerate(options, start=1):
            self._out(f"    {idx}. {opt}")
        while True:
            raw = self._prompt(f"  Select option (1-{len(options)}) or type value: ")
            if raw.lower() == "cancel":
                raise InterruptedError("Action cancelled by user.")
            if raw.isdigit():
                index = int(raw) - 1
                if 0 <= index < len(options):
                    return options[index]
            for opt in options:
                if opt.lower() == raw.lower():
                    return opt
            self._out("  [Invalid] Please choose a valid number or option name.")

    def _print_header(self, title: str) -> None:
        bar = "=" * 68
        self._out(f"\n{bar}")
        self._out(f"  {title}")
        self._out(bar)

    def _print_records_table(self, records: list[SurveyRecord]) -> None:
        if not records:
            self._out("  No matching survey records found.")
            return
        header = (
            f"  {'ID':<10} {'Name':<20} {'Department':<18} {'Year':<13} "
            f"{'Score':>5} {'Sat':>4} {'Hrs':>4} {'Att%':>5} {'Date':<10}"
        )
        self._out(header)
        self._out("  " + "-" * (len(header) - 2))
        for r in records:
            self._out(
                f"  {r.student_id:<10} {r.name[:19]:<20} {r.department[:17]:<18} {r.year[:12]:<13} "
                f"{r.score:>5} {r.satisfaction:>4} {r.study_hours:>4} {r.attendance:>4}% {r.date:<10}"
            )

    # ---- MENU HANDLERS (SRS Section 4.1) ----

    def show_dashboard_summary(self) -> None:
        """Display executive KPI cards and active threshold warnings."""
        self._print_header("STUDENT SURVEY DASHBOARD — EXECUTIVE SUMMARY")
        summary = self.service.get_executive_summary()
        self._out(f"  Total Responses   : {summary['totalResponses']}")
        self._out(f"  Average Score     : {summary['avgScore']} / 100 (Median: {summary['medianScore']}, Std: {summary['stdScore']})")
        self._out(f"  Score Range       : {summary['minScore']} – {summary['maxScore']}")
        self._out(f"  Avg Satisfaction  : {summary['avgSatisfaction']} / 10")
        self._out(f"  Avg Study Hours   : {summary['avgStudyHours']} hrs/week")
        self._out(f"  Avg Attendance    : {summary['avgAttendance']}%")
        self._out(f"  High Achievers    : {summary['highAchieversCount']} (Score >= 75)")
        self._out(f"  Top Department    : {summary['topDepartment']}")

        warnings = summary["warnings"]
        self._out("\n  Threshold Warnings:")
        if not warnings:
            self._out("    [OK] No threshold breaches detected.")
        else:
            for warn in warnings:
                self._out(f"    [!] {warn['message']}")

    def handle_add_entry(self) -> None:
        """Interactive wizard to add a validated student survey entry."""
        self._print_header("ADD NEW SURVEY ENTRY")
        self._out("  (Type 'cancel' at any prompt to return to the main menu)")
        try:
            name = self._prompt_validated("  Student Name (2+ chars): ", "name")
            student_id = self._prompt_validated("  Student ID (e.g. STU-101): ", "student_id")
            department = self._prompt_choice("Department", DEPARTMENTS)
            year = self._prompt_choice("Year of Study", YEARS_OF_STUDY)
            score = self._prompt_validated("  Academic Score (0–100): ", "score")
            satisfaction = self._prompt_validated("  Satisfaction Rating (1–10): ", "satisfaction")
            study_hours = self._prompt_validated("  Weekly Study Hours (0–168): ", "study_hours")
            attendance = self._prompt_validated("  Attendance % (0–100): ", "attendance")
            feedback = self._prompt("  Feedback / Comments (optional): ")

            record = self.service.add_record(
                {
                    "name": name,
                    "studentId": student_id,
                    "department": department,
                    "year": year,
                    "score": score,
                    "satisfaction": satisfaction,
                    "studyHours": study_hours,
                    "attendance": attendance,
                    "feedback": feedback,
                }
            )
            self._out(f"\n  [SUCCESS] Saved record for {record.name} ({record.student_id}).")
        except InterruptedError as exc:
            self._out(f"  {exc}")
        except ValidationError as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_browse_records(self) -> None:
        """Browse all records with interactive pagination."""
        self._print_header("BROWSE SURVEY RECORDS")
        records = self.service.list_records()
        total = len(records)
        if total == 0:
            self._out("  No records available.")
            return

        total_pages = max(1, (total + PAGE_SIZE_DEFAULT - 1) // PAGE_SIZE_DEFAULT)
        page = 1
        while True:
            start = (page - 1) * PAGE_SIZE_DEFAULT
            end = start + PAGE_SIZE_DEFAULT
            self._out(f"\n  Page {page} of {total_pages} (Total: {total} records)")
            self._print_records_table(records[start:end])
            if total_pages == 1:
                break
            cmd = self._prompt("  [n]ext, [p]rev, or [q]uit browsing: ").lower()
            if cmd == "n" and page < total_pages:
                page += 1
            elif cmd == "p" and page > 1:
                page -= 1
            elif cmd in ("q", ""):
                break

    def handle_search_filter(self) -> None:
        """Filter records using Pandas multi-criteria query."""
        self._print_header("SEARCH & FILTER RECORDS (PANDAS)")
        query = self._prompt("  Search name or Student ID (blank for all): ")
        department = self._prompt("  Department filter (blank for all): ")
        year = self._prompt("  Year filter (blank for all): ")
        min_score_raw = self._prompt("  Minimum score (0–100, blank for none): ")
        max_score_raw = self._prompt("  Maximum score (0–100, blank for none): ")

        try:
            min_score = int(min_score_raw) if min_score_raw else None
            max_score = int(max_score_raw) if max_score_raw else None
        except ValueError:
            self._out("  [ERROR] Score bounds must be integers.")
            return

        criteria = FilterCriteria(
            query=query,
            department=department,
            year=year,
            min_score=min_score,
            max_score=max_score,
        )
        matches = self.service.filter_records(criteria)
        self._out(f"\n  Matched {len(matches)} record(s):")
        self._print_records_table(matches)

    def handle_edit_record(self) -> None:
        """Edit an existing survey record by Student ID."""
        self._print_header("EDIT SURVEY RECORD")
        sid = self._prompt("  Enter Student ID to edit (e.g. STU-001): ")
        try:
            current = self.service.get_record_by_student_id(sid)
        except RecordNotFoundError as exc:
            self._out(f"  [ERROR] {exc}")
            return

        self._out(f"  Editing {current.name} ({current.student_id}) — press Enter to keep current value:")
        name = self._prompt(f"  Name [{current.name}]: ") or current.name
        score = self._prompt(f"  Score [{current.score}]: ") or str(current.score)
        satisfaction = self._prompt(f"  Satisfaction [{current.satisfaction}]: ") or str(current.satisfaction)
        study_hours = self._prompt(f"  Study Hours [{current.study_hours}]: ") or str(current.study_hours)
        attendance = self._prompt(f"  Attendance [{current.attendance}]: ") or str(current.attendance)
        feedback = self._prompt(f"  Feedback [{current.feedback}]: ")
        if feedback == "":
            feedback = current.feedback

        try:
            updated = self.service.update_record(
                current.student_id,
                {
                    "name": name,
                    "score": score,
                    "satisfaction": satisfaction,
                    "studyHours": study_hours,
                    "attendance": attendance,
                    "feedback": feedback,
                },
            )
            self._out(f"  [SUCCESS] Updated {updated.student_id} (Score: {updated.score}, Sat: {updated.satisfaction}).")
        except ValidationError as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_delete_record(self) -> None:
        """Delete a survey record with confirmation and optional PIN check."""
        self._print_header("DELETE SURVEY RECORD")
        sid = self._prompt("  Enter Student ID to delete: ")
        confirm = self._prompt(f"  Confirm permanent deletion of '{sid}'? (yes/no): ").lower()
        if confirm not in ("y", "yes"):
            self._out("  Deletion cancelled.")
            return

        pin = None
        if self.service.config.admin_pin_hash is not None:
            pin = self._prompt("  Enter Admin PIN: ")

        try:
            deleted = self.service.delete_record(sid, pin=pin)
            self._out(f"  [SUCCESS] Deleted {deleted.name} ({deleted.student_id}).")
        except (RecordNotFoundError, SecurityError) as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_analytics(self) -> None:
        """Display department/year breakdowns, correlations, and at-risk students."""
        self._print_header("PANDAS ANALYTICS, CORRELATIONS & AT-RISK STUDENTS")
        summary = self.service.get_executive_summary()
        corr = summary["correlations"]
        self._out("  Correlations (Pearson r):")
        self._out(f"    Score vs Satisfaction : {corr.get('scoreVsSatisfaction', 0.0)}")
        self._out(f"    Score vs Study Hours  : {corr.get('scoreVsStudyHours', 0.0)}")
        self._out(f"    Score vs Attendance   : {corr.get('scoreVsAttendance', 0.0)}")

        self._out("\n  Department Breakdown:")
        self._out(f"    {'Department':<20} {'Count':>5} {'AvgScore':>9} {'AvgSat':>7} {'AvgHrs':>7} {'AvgAtt%':>8}")
        for d in summary["departments"]:
            self._out(
                f"    {d['department']:<20} {d['count']:>5} {d['avgScore']:>9.2f} "
                f"{d['avgSatisfaction']:>7.2f} {d['avgStudyHours']:>7.2f} {d['avgAttendance']:>7.2f}%"
            )

        self._out("\n  Year-wise Progression:")
        for y in summary["years"]:
            self._out(f"    {y['year']:<14} Count: {y['count']:<4} AvgScore: {y['avgScore']:<6} AvgSat: {y['avgSatisfaction']}")

        at_risk = self.service.get_at_risk_students()
        self._out(f"\n  At-Risk Students Identified: {len(at_risk)}")
        for row in at_risk[:10]:
            self._out(
                f"    - {row['studentId']} ({row['name']}): Score={row['score']}, "
                f"Att={row['attendance']}%, Sat={row['satisfaction']}/10 [Flags={row['riskFlags']}]"
            )

    def handle_generate_charts(self) -> None:
        """Generate all Matplotlib charts to outputs/charts/."""
        self._print_header("GENERATE MATPLOTLIB VISUALIZATIONS")
        try:
            paths = self.service.generate_charts()
            self._out(f"  [SUCCESS] Generated {len(paths)} chart(s) in: {self.service.config.charts_dir}")
            for path in paths:
                self._out(f"    - {path.name}")
        except VisualizationError as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_export(self) -> None:
        """Export survey data or summary report in CSV, JSON, Markdown, or Text."""
        self._print_header("EXPORT DATA & EXECUTIVE REPORTS")
        fmt = self._prompt("  Choose format (csv / json / md / txt / all): ").lower()
        formats = ["csv", "json", "md", "txt"] if fmt == "all" else [fmt]
        for target_fmt in formats:
            try:
                path = self.service.export_data(target_fmt)
                self._out(f"  [SUCCESS] Exported {target_fmt.upper()} -> {path}")
            except (ValueError, SecurityError) as exc:
                self._out(f"  [ERROR] {exc}")

    def handle_import_csv(self) -> None:
        """Bulk import student records from a CSV file."""
        self._print_header("BULK IMPORT CSV")
        self._out(f"  Allowed base directories: {self.service.config.data_dir}, {self.service.config.base_dir}")
        csv_path = self._prompt("  Enter CSV file path (relative to data/ or project root): ")
        try:
            summary = self.service.import_csv(csv_path)
            self._out(f"  [DONE] Imported {summary.added} record(s), skipped {summary.skipped}.")
            for err in summary.errors[:5]:
                self._out(f"    - {err}")
        except (FileNotFoundError, SecurityError, ValueError) as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_reset_seed(self) -> None:
        """Reset survey dataset to default 35 seeded sample records."""
        self._print_header("RESET TO SAMPLE DATASET")
        confirm = self._prompt("  Overwrite current dataset with 35 sample records? (yes/no): ").lower()
        if confirm not in ("y", "yes"):
            self._out("  Reset cancelled.")
            return
        pin = None
        if self.service.config.admin_pin_hash is not None:
            pin = self._prompt("  Enter Admin PIN: ")
        try:
            records = self.service.reset_to_sample_data(35, pin=pin)
            self._out(f"  [SUCCESS] Dataset reset to {len(records)} sample records.")
        except SecurityError as exc:
            self._out(f"  [ERROR] {exc}")

    def handle_launch_web(self) -> None:
        """Start the browser web dashboard server from inside the CLI menu."""
        from survey_dashboard.presentation.web import serve_web_app

        self._print_header("LAUNCH BROWSER WEB DASHBOARD")
        serve_web_app(
            service=self.service,
            config=self.service.config,
            host="127.0.0.1",
            port=8787,
            open_browser=True,
        )

    def run_interactive(self) -> None:
        """Run the SRS Section 4.1 numbered interactive CLI loop."""
        actions: dict[str, Callable[[], None]] = {
            "1": self.show_dashboard_summary,
            "2": self.handle_add_entry,
            "3": self.handle_browse_records,
            "4": self.handle_search_filter,
            "5": self.handle_edit_record,
            "6": self.handle_delete_record,
            "7": self.handle_analytics,
            "8": self.handle_generate_charts,
            "9": self.handle_export,
            "10": self.handle_import_csv,
            "11": self.handle_reset_seed,
            "12": self.handle_launch_web,
        }

        while True:
            self._print_header("STUDENT SURVEY DASHBOARD — MAIN MENU (SRS §4.1)")
            self._out(f"  Active Records: {len(self.service.list_records())}")
            self._out("   1. View Dashboard Summary & Warnings")
            self._out("   2. Add New Survey Entry")
            self._out("   3. Browse All Records (Paginated)")
            self._out("   4. Search & Filter Records (Pandas)")
            self._out("   5. Edit Existing Record")
            self._out("   6. Delete Record")
            self._out("   7. View Analytics, Correlations & At-Risk Students")
            self._out("   8. Generate Matplotlib Visualizations (PNG)")
            self._out("   9. Export Data & Reports (CSV / JSON / MD / TXT)")
            self._out("  10. Bulk Import Records from CSV")
            self._out("  11. Reset to Sample Dataset (35 Records)")
            self._out("  12. Launch Browser Web Dashboard")
            self._out("   0. Exit")

            try:
                choice = self._prompt("\n  Enter choice [0–12]: ")
            except (EOFError, KeyboardInterrupt):
                self._out("\n  Exiting Student Survey Dashboard. Goodbye!")
                break

            if choice == "0":
                self._out("  Exiting Student Survey Dashboard. Goodbye!")
                break

            handler = actions.get(choice)
            if handler:
                try:
                    handler()
                except (EOFError, KeyboardInterrupt):
                    self._out("\n  Operation interrupted.")
            else:
                self._out("  [Invalid] Please choose a menu number between 0 and 12.")


def build_arg_parser() -> argparse.ArgumentParser:
    """Create the CLI argument parser for interactive, web, or automated execution."""
    parser = argparse.ArgumentParser(
        prog="student-survey-dashboard",
        description="3-Tier Student Survey Dashboard (CLI, Browser Web UI, Pandas Analytics, Matplotlib Charts, CSV/JSON Persistence).",
    )
    parser.add_argument("--data-dir", type=Path, default=None, help="Override project root directory for data/outputs.")
    parser.add_argument("--admin-pin", type=str, default=None, help="Optional Admin PIN required for delete/reset actions.")
    parser.add_argument("--web", action="store_true", help="Launch the browser-based web dashboard backed by Python Tier 2.")
    parser.add_argument("--open", action="store_true", help="Automatically open the default browser when --web starts.")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Host interface for --web server (default: 127.0.0.1).")
    parser.add_argument("--port", type=int, default=8787, help="Port for --web server (default: 8787).")
    parser.add_argument("--summary", action="store_true", help="Print executive summary and exit.")
    parser.add_argument("--charts", action="store_true", help="Generate all Matplotlib PNG charts and exit.")
    parser.add_argument("--export", choices=["csv", "json", "md", "txt", "all"], help="Export report/data and exit.")
    return parser


def main(argv: list[str] | None = None) -> int:
    """Application CLI entrypoint."""
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    pin_hash = hash_pin(args.admin_pin) if args.admin_pin else None
    config = AppConfig.from_base_dir(base_dir=args.data_dir, admin_pin_hash=pin_hash)

    try:
        repository = FileSurveyRepository(config)
        service = SurveyService(repository=repository, config=config)
    except PersistenceError as exc:
        print(f"[FATAL] Storage initialization error: {exc}")
        return 1

    if args.web:
        from survey_dashboard.presentation.web import serve_web_app

        serve_web_app(service=service, config=config, host=args.host, port=args.port, open_browser=args.open)
        return 0

    cli = SurveyCLI(service=service)

    ran_non_interactive = False
    if args.summary:
        cli.show_dashboard_summary()
        ran_non_interactive = True
    if args.charts:
        cli.handle_generate_charts()
        ran_non_interactive = True
    if args.export:
        fmt_list = ["csv", "json", "md", "txt"] if args.export == "all" else [args.export]
        for fmt in fmt_list:
            out = service.export_data(fmt)
            print(f"[SUCCESS] Exported {fmt.upper()} -> {out}")
        ran_non_interactive = True

    if not ran_non_interactive:
        cli.run_interactive()

    return 0
