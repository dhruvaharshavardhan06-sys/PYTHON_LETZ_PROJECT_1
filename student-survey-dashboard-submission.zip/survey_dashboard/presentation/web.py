"""Tier 3 — Web Presentation Layer: Built-in Python HTTP server & JSON API backed by SurveyService."""

from __future__ import annotations

import json
import mimetypes
import threading
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from survey_dashboard.business.security import SecurityError, safe_resolve_path
from survey_dashboard.business.service import RecordNotFoundError, SurveyService
from survey_dashboard.business.validators import ValidationError, validate_and_build_record
from survey_dashboard.business.visualizer import VisualizationError
from survey_dashboard.config import AppConfig

DEFAULT_WEB_DIR = Path(__file__).resolve().parent.parent.parent / "web"
MAX_REQUEST_BYTES = 2 * 1024 * 1024  # 2 MB cap on JSON payloads


def create_web_handler(service: SurveyService, web_dir: Path, service_lock: threading.Lock) -> type[BaseHTTPRequestHandler]:
    """Create an HTTP request handler bound to ``service`` and static ``web_dir``."""

    class SurveyWebHandler(BaseHTTPRequestHandler):
        """Serves the browser dashboard UI and REST API over Python's SurveyService."""

        server_version = "StudentSurveyDashboard/1.0"

        def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
            # Suppress noisy stderr logging during tests; concise stdout is optional
            return

        def _send_json(self, status: int, payload: Any) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _send_bytes(self, status: int, content_type: str, data: bytes, download_name: str | None = None) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            if download_name:
                self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
            self.end_headers()
            self.wfile.write(data)

        def _read_json_body(self) -> dict[str, Any]:
            length_raw = self.headers.get("Content-Length", "0")
            try:
                length = int(length_raw)
            except ValueError as exc:
                raise ValueError("Invalid Content-Length header.") from exc
            if length <= 0 or length > MAX_REQUEST_BYTES:
                raise ValueError(f"Request body must be between 1 and {MAX_REQUEST_BYTES} bytes.")
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("JSON request body must be an object.")
            return data

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/api/health":
                self._send_json(HTTPStatus.OK, {"status": "ok", "records": len(service.list_records())})
                return

            if path == "/api/records":
                with service_lock:
                    records = [r.to_dict() for r in service.list_records()]
                self._send_json(HTTPStatus.OK, {"records": records})
                return

            if path == "/api/summary":
                with service_lock:
                    summary = service.get_executive_summary()
                    at_risk = service.get_at_risk_students()
                summary["atRisk"] = at_risk
                self._send_json(HTTPStatus.OK, summary)
                return

            if path.startswith("/api/export/"):
                fmt = path.removeprefix("/api/export/").strip().lower()
                mime_map = {
                    "csv": ("text/csv; charset=utf-8", "survey_data.csv"),
                    "json": ("application/json; charset=utf-8", "survey_data.json"),
                    "md": ("text/markdown; charset=utf-8", "survey_report.md"),
                    "txt": ("text/plain; charset=utf-8", "survey_report.txt"),
                }
                if fmt not in mime_map:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": f"Unsupported format '{fmt}'."})
                    return
                with service_lock:
                    out_path = service.export_data(fmt)
                ctype, fname = mime_map[fmt]
                self._send_bytes(HTTPStatus.OK, ctype, out_path.read_bytes(), download_name=fname)
                return

            if path.startswith("/api/charts/"):
                chart_name = unquote(path.removeprefix("/api/charts/")).strip()
                try:
                    chart_path = safe_resolve_path(chart_name, (service.config.charts_dir,))
                except SecurityError as exc:
                    self._send_json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
                    return
                if not chart_path.exists() or not chart_path.is_file():
                    self._send_json(HTTPStatus.NOT_FOUND, {"error": "Chart not found."})
                    return
                self._send_bytes(HTTPStatus.OK, "image/png", chart_path.read_bytes())
                return

            # Static web assets
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            try:
                asset_path = safe_resolve_path(rel, (web_dir,))
            except SecurityError as exc:
                self._send_json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
                return

            if not asset_path.exists() or not asset_path.is_file():
                self._send_json(HTTPStatus.NOT_FOUND, {"error": "Not found."})
                return

            mime, _ = mimetypes.guess_type(str(asset_path))
            content_type = mime or "application/octet-stream"
            if content_type.startswith("text/") or content_type == "application/javascript":
                content_type += "; charset=utf-8"
            self._send_bytes(HTTPStatus.OK, content_type, asset_path.read_bytes())

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/api/records":
                try:
                    payload = self._read_json_body()
                    with service_lock:
                        created = service.add_record(payload)
                    self._send_json(HTTPStatus.CREATED, {"record": created.to_dict()})
                except ValidationError as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc), "errors": exc.errors})
                except (ValueError, json.JSONDecodeError) as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return

            if path == "/api/import":
                try:
                    payload = self._read_json_body()
                    rows = payload.get("rows")
                    if not isinstance(rows, list):
                        raise ValueError("Payload must include a 'rows' list.")
                    added = 0
                    skipped = 0
                    errors: list[str] = []
                    with service_lock:
                        existing = service.list_records()
                        for idx, row in enumerate(rows, start=1):
                            if not isinstance(row, dict):
                                skipped += 1
                                continue
                            try:
                                validate_and_build_record(row, existing_records=existing)
                                rec = service.add_record(row)
                                existing.append(rec)
                                added += 1
                            except Exception as exc:
                                skipped += 1
                                errors.append(f"Row {idx}: {exc}")
                    self._send_json(HTTPStatus.OK, {"added": added, "skipped": skipped, "errors": errors[:10]})
                except (ValueError, json.JSONDecodeError) as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return

            if path == "/api/charts":
                try:
                    with service_lock:
                        paths = service.generate_charts()
                    self._send_json(HTTPStatus.OK, {"charts": [p.name for p in paths]})
                except VisualizationError as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return

            if path == "/api/reset":
                try:
                    body = self._read_json_body() if int(self.headers.get("Content-Length", "0") or 0) > 0 else {}
                    pin = body.get("pin")
                    with service_lock:
                        records = service.reset_to_sample_data(35, pin=pin)
                    self._send_json(HTTPStatus.OK, {"count": len(records)})
                except SecurityError as exc:
                    self._send_json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
                except (ValueError, json.JSONDecodeError) as exc:
                    self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return

            self._send_json(HTTPStatus.NOT_FOUND, {"error": "Unknown API endpoint."})

        def do_PUT(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path
            if not path.startswith("/api/records/"):
                self._send_json(HTTPStatus.NOT_FOUND, {"error": "Unknown API endpoint."})
                return

            student_id = unquote(path.removeprefix("/api/records/")).strip()
            try:
                payload = self._read_json_body()
                with service_lock:
                    updated = service.update_record(student_id, payload)
                self._send_json(HTTPStatus.OK, {"record": updated.to_dict()})
            except RecordNotFoundError as exc:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": str(exc)})
            except ValidationError as exc:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc), "errors": exc.errors})
            except (ValueError, json.JSONDecodeError) as exc:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})

        def do_DELETE(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            path = parsed.path
            if not path.startswith("/api/records/"):
                self._send_json(HTTPStatus.NOT_FOUND, {"error": "Unknown API endpoint."})
                return

            student_id = unquote(path.removeprefix("/api/records/")).strip()
            pin = self.headers.get("X-Admin-Pin")
            try:
                with service_lock:
                    deleted = service.delete_record(student_id, pin=pin)
                self._send_json(HTTPStatus.OK, {"deleted": deleted.to_dict()})
            except SecurityError as exc:
                self._send_json(HTTPStatus.FORBIDDEN, {"error": str(exc)})
            except RecordNotFoundError as exc:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": str(exc)})

    return SurveyWebHandler


def create_server(
    service: SurveyService,
    host: str = "127.0.0.1",
    port: int = 8787,
    web_dir: Path | None = None,
) -> ThreadingHTTPServer:
    """Instantiate a configured ThreadingHTTPServer without blocking."""
    resolved_web_dir = (web_dir or DEFAULT_WEB_DIR).resolve()
    lock = threading.Lock()
    handler_cls = create_web_handler(service=service, web_dir=resolved_web_dir, service_lock=lock)
    return ThreadingHTTPServer((host, port), handler_cls)


def serve_web_app(
    service: SurveyService,
    config: AppConfig,
    host: str = "127.0.0.1",
    port: int = 8787,
    web_dir: Path | None = None,
    open_browser: bool = False,
) -> None:
    """Start the browser dashboard HTTP server until interrupted, falling back to the next free port if busy."""
    server: ThreadingHTTPServer | None = None
    for candidate_port in range(port, port + 20):
        try:
            server = create_server(service=service, host=host, port=candidate_port, web_dir=web_dir)
            break
        except OSError:
            continue
    if server is None:
        server = create_server(service=service, host=host, port=0, web_dir=web_dir)

    actual_port = server.server_address[1]
    url = f"http://{host}:{actual_port}"
    print(f"Student Survey Dashboard (3-Tier Python Web Server) running at: {url}", flush=True)
    print(f"Data directory: {config.data_dir}", flush=True)
    print("Press Ctrl+C to stop the server.", flush=True)
    if open_browser:
        threading.Timer(0.4, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down web server...")
    finally:
        server.server_close()
